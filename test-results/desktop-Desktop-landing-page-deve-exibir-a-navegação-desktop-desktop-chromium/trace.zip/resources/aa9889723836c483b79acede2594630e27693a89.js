import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sections/FAQSection.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=12888fd9";
import { faqs } from "/src/data/landingData.js";
var _jsxFileName = "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/FAQSection.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12888fd9";
var _s = $RefreshSig$();
export default function FAQSection() {
	_s();
	const [openFaq, setOpenFaq] = useState(0);
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "faq",
		"data-reveal": true,
		className: "scroll-mt-28 reveal-up rounded-2xl border border-zinc-800 bg-zinc-900/40 p-8",
		children: [/* @__PURE__ */ _jsxDEV("h2", {
			className: "mb-6 text-2xl font-semibold md:text-3xl",
			children: "Perguntas Frequentes"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 13,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "space-y-3",
			children: faqs.map((item, index) => {
				const isOpen = openFaq === index;
				return /* @__PURE__ */ _jsxDEV("div", {
					className: "rounded-lg border border-zinc-700 bg-zinc-950/40 transition-colors duration-300 hover:border-blue-400/40",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => setOpenFaq(isOpen ? -1 : index),
						className: "flex w-full items-center justify-between px-4 py-3 text-left transition-colors duration-300 hover:text-blue-200",
						"aria-expanded": isOpen,
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "font-medium",
							children: item.q
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 34,
							columnNumber: 33
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: `text-blue-300 transition-transform duration-300 ${isOpen ? "rotate-180" : ""}`,
							"aria-hidden": "true",
							children: "+"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 38,
							columnNumber: 33
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 26,
						columnNumber: 29
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: `faq-content px-4 text-zinc-300 ${isOpen ? "faq-open pb-4" : ""}`,
						children: /* @__PURE__ */ _jsxDEV("p", { children: item.a }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 53,
							columnNumber: 33
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 48,
						columnNumber: 29
					}, this)]
				}, item.q, true, {
					fileName: _jsxFileName,
					lineNumber: 22,
					columnNumber: 25
				}, this);
			})
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 13
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 8,
		columnNumber: 9
	}, this);
}
_s(FAQSection, "UxfrzqBwOgsnLfeQ4ctKm+F6jTk=");
_c = FAQSection;
var _c;
$RefreshReg$(_c, "FAQSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/sections/FAQSection.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/FAQSection.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/FAQSection.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/FAQSection.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxZQUFZOzs7O0FBRXJCLGVBQWUsU0FBUyxhQUFhOztDQUNqQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsQ0FBQztDQUV4QyxPQUNJLHdCQUFDLFdBQUQ7RUFDSSxJQUFHO0VBQ0g7RUFDQSxXQUFVO1lBSGQsQ0FLSSx3QkFBQyxNQUFEO0dBQUksV0FBVTthQUEwQztFQUVwRDs7OztZQUVKLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ1YsS0FBSyxLQUFLLE1BQU0sVUFBVTtJQUN2QixNQUFNLFNBQVMsWUFBWTtJQUUzQixPQUNJLHdCQUFDLE9BQUQ7S0FFSSxXQUFVO2VBRmQsQ0FJSSx3QkFBQyxVQUFEO01BQ0ksTUFBSztNQUNMLGVBQ0ksV0FBVyxTQUFTLENBQUMsSUFBSSxLQUFLO01BRWxDLFdBQVU7TUFDVixpQkFBZTtnQkFObkIsQ0FRSSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFDWCxLQUFLO01BQ0o7Ozs7Z0JBRU4sd0JBQUMsUUFBRDtPQUNJLFdBQVcsbURBQ1AsU0FBUyxlQUFlO09BRTVCLGVBQVk7aUJBQ2Y7TUFFSzs7OztjQUNGOzs7OztlQUVSLHdCQUFDLE9BQUQ7TUFDSSxXQUFXLGtDQUNQLFNBQVMsa0JBQWtCO2dCQUcvQix3QkFBQyxLQUFELFlBQUksS0FBSyxFQUFLOzs7OztLQUNiOzs7O2FBQ0o7T0FoQ0ksS0FBSzs7OztXQWdDVDtHQUViLENBQUM7RUFDQTs7OztVQUNBOzs7Ozs7QUFFakIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRkFRU2VjdGlvbi5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgZmFxcyB9IGZyb20gXCIuLi8uLi9kYXRhL2xhbmRpbmdEYXRhXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBGQVFTZWN0aW9uKCkge1xyXG4gICAgY29uc3QgW29wZW5GYXEsIHNldE9wZW5GYXFdID0gdXNlU3RhdGUoMCk7XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8c2VjdGlvblxyXG4gICAgICAgICAgICBpZD1cImZhcVwiXHJcbiAgICAgICAgICAgIGRhdGEtcmV2ZWFsXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInNjcm9sbC1tdC0yOCByZXZlYWwtdXAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci16aW5jLTgwMCBiZy16aW5jLTkwMC80MCBwLThcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cIm1iLTYgdGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtZDp0ZXh0LTN4bFwiPlxyXG4gICAgICAgICAgICAgICAgUGVyZ3VudGFzIEZyZXF1ZW50ZXNcclxuICAgICAgICAgICAgPC9oMj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XHJcbiAgICAgICAgICAgICAgICB7ZmFxcy5tYXAoKGl0ZW0sIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNPcGVuID0gb3BlbkZhcSA9PT0gaW5kZXhcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpdGVtLnF9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJvcmRlciBib3JkZXItemluYy03MDAgYmctemluYy05NTAvNDAgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMzAwIGhvdmVyOmJvcmRlci1ibHVlLTQwMC80MFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0T3BlbkZhcShpc09wZW4gPyAtMSA6IGluZGV4KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IHctZnVsbCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTQgcHktMyB0ZXh0LWxlZnQgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMzAwIGhvdmVyOnRleHQtYmx1ZS0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtZXhwYW5kZWQ9e2lzT3Blbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5xfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC1ibHVlLTMwMCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDAgJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzT3BlbiA/IFwicm90YXRlLTE4MFwiIDogXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmFxLWNvbnRlbnQgcHgtNCB0ZXh0LXppbmMtMzAwICR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzT3BlbiA/IFwiZmFxLW9wZW4gcGItNFwiIDogXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwPntpdGVtLmF9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICApXHJcbn0iXX0=