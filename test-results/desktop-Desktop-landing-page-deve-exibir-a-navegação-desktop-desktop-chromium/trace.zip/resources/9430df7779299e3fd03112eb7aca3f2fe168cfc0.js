import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/SiteFooter.jsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { FaEnvelope, FaLinkedin, FaPhone } from "/node_modules/.vite/deps/react-icons_fa.js?v=12888fd9";
import { FaXTwitter } from "/node_modules/.vite/deps/react-icons_fa6.js?v=12888fd9";
var _jsxFileName = "C:/Users/uelin/Desktop/AI Company Landing/src/components/layout/SiteFooter.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12888fd9";
export default function SiteFooter() {
	const linkClasses = "inline-flex items-center gap-2 text-zinc-400 transition-colors duration-200 hover:text-blue-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 focus-visible:ring-offset-2 focus-visible:ring-offset-zinc-950 rounded";
	return /* @__PURE__ */ _jsxDEV("footer", {
		className: "mt-20 border-t border-zinc-800 py-8",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col gap-8 sm:flex-row sm:items-start sm:justify-between",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-5",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "mb-3 text-sm font-semibold uppercase tracking-wide text-zinc-200",
					children: "Contato"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 13,
					columnNumber: 25
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col gap-3",
					children: [/* @__PURE__ */ _jsxDEV("a", {
						href: "mailto:ola@exemplo.com",
						className: linkClasses,
						children: [/* @__PURE__ */ _jsxDEV(FaEnvelope, { "aria-hidden": "true" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 22,
							columnNumber: 33
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "ola@exemplo.com" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 23,
							columnNumber: 33
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 18,
						columnNumber: 29
					}, this), /* @__PURE__ */ _jsxDEV("a", {
						href: "tel:+123456789000",
						className: linkClasses,
						children: [/* @__PURE__ */ _jsxDEV(FaPhone, { "aria-hidden": "true" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 30,
							columnNumber: 33
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "+12 (34) 5678-9000" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 31,
							columnNumber: 33
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 26,
						columnNumber: 29
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 17,
					columnNumber: 25
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 12,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "mb-3 text-sm font-semibold uppercase tracking-wide text-zinc-200",
					children: "Redes sociais"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 37,
					columnNumber: 25
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col gap-3",
					children: [/* @__PURE__ */ _jsxDEV("a", {
						href: "#",
						target: "_blank",
						rel: "noopener noreferrer",
						className: linkClasses,
						children: [/* @__PURE__ */ _jsxDEV(FaLinkedin, { "aria-hidden": "true" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 48,
							columnNumber: 33
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "LinkedIn" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 49,
							columnNumber: 33
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 42,
						columnNumber: 29
					}, this), /* @__PURE__ */ _jsxDEV("a", {
						href: "#",
						target: "_blank",
						rel: "noopener noreferrer",
						className: linkClasses,
						children: [/* @__PURE__ */ _jsxDEV(FaXTwitter, { "aria-hidden": "true" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 58,
							columnNumber: 33
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "X / Twitter" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 59,
							columnNumber: 33
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 29
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 41,
					columnNumber: 25
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 17
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-center text-sm text-zinc-500 sm:text-right",
				children: "© 2026 Synapse IA. Todos os direitos reservados."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 65,
				columnNumber: 17
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 10,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 9,
		columnNumber: 9
	}, this);
}
_c = SiteFooter;
var _c;
$RefreshReg$(_c, "SiteFooter");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/SiteFooter.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/uelin/Desktop/AI Company Landing/src/components/layout/SiteFooter.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/uelin/Desktop/AI Company Landing/src/components/layout/SiteFooter.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/uelin/Desktop/AI Company Landing/src/components/layout/SiteFooter.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZLFlBQVksZUFBZTtBQUNoRCxTQUFTLGtCQUFrQjs7O0FBRTNCLGVBQWUsU0FBUyxhQUFhO0NBQ2pDLE1BQU0sY0FDRjtDQUVKLE9BQ0ksd0JBQUMsVUFBRDtFQUFRLFdBQVU7WUFDZCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0ksd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNJLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFtRTtJQUU3RTs7OztjQUVKLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDSSx3QkFBQyxLQUFEO01BQ0ksTUFBSztNQUNMLFdBQVc7Z0JBRmYsQ0FJSSx3QkFBQyxZQUFELEVBQVksZUFBWSxPQUFROzs7O2dCQUNoQyx3QkFBQyxRQUFELFlBQU0sa0JBQXFCOzs7O2NBQzVCOzs7OztlQUVILHdCQUFDLEtBQUQ7TUFDSSxNQUFLO01BQ0wsV0FBVztnQkFGZixDQUlJLHdCQUFDLFNBQUQsRUFBUyxlQUFZLE9BQVE7Ozs7Z0JBQzdCLHdCQUFDLFFBQUQsWUFBTSxxQkFBd0I7Ozs7Y0FDL0I7Ozs7O2FBQ0Y7Ozs7O1lBQ0o7Ozs7Y0FFTCx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBbUU7SUFFN0U7Ozs7Y0FFSix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0ksd0JBQUMsS0FBRDtNQUNJLE1BQUs7TUFDTCxRQUFPO01BQ1AsS0FBSTtNQUNKLFdBQVc7Z0JBSmYsQ0FNSSx3QkFBQyxZQUFELEVBQVksZUFBWSxPQUFROzs7O2dCQUNoQyx3QkFBQyxRQUFELFlBQU0sV0FBYzs7OztjQUNyQjs7Ozs7ZUFFSCx3QkFBQyxLQUFEO01BQ0ksTUFBSztNQUNMLFFBQU87TUFDUCxLQUFJO01BQ0osV0FBVztnQkFKZixDQU1JLHdCQUFDLFlBQUQsRUFBWSxlQUFZLE9BQVE7Ozs7Z0JBQ2hDLHdCQUFDLFFBQUQsWUFBTSxjQUFpQjs7OztjQUN4Qjs7Ozs7YUFDRjs7Ozs7WUFDSjs7OztZQUNKOzs7OzthQUVMLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQWtEO0dBRTVEOzs7O1dBQ0Y7Ozs7OztDQUNEOzs7OztBQUVoQiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTaXRlRm9vdGVyLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGYUVudmVsb3BlLCBGYUxpbmtlZGluLCBGYVBob25lIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IEZhWFR3aXR0ZXIgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmE2XCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTaXRlRm9vdGVyKCkge1xyXG4gICAgY29uc3QgbGlua0NsYXNzZXMgPVxyXG4gICAgICAgIFwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtemluYy00MDAgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMjAwIGhvdmVyOnRleHQtYmx1ZS0zMDAgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW5vbmUgZm9jdXMtdmlzaWJsZTpyaW5nLTIgZm9jdXMtdmlzaWJsZTpyaW5nLWJsdWUtNDAwIGZvY3VzLXZpc2libGU6cmluZy1vZmZzZXQtMiBmb2N1cy12aXNpYmxlOnJpbmctb2Zmc2V0LXppbmMtOTUwIHJvdW5kZWRcIlxyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGZvb3RlciBjbGFzc05hbWU9XCJtdC0yMCBib3JkZXItdCBib3JkZXItemluYy04MDAgcHktOFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTggc206ZmxleC1yb3cgc206aXRlbXMtc3RhcnQgc206anVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi0zIHRleHQtc20gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSB0ZXh0LXppbmMtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDb250YXRvXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaHJlZj1cIm1haWx0bzpvbGFAZXhlbXBsby5jb21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17bGlua0NsYXNzZXN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhRW52ZWxvcGUgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5vbGFAZXhlbXBsby5jb208L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBocmVmPVwidGVsOisxMjM0NTY3ODkwMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17bGlua0NsYXNzZXN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhUGhvbmUgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj4rMTIgKDM0KSA1Njc4LTkwMDA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItMyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgdGV4dC16aW5jLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVkZXMgc29jaWFpc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBocmVmPVwiI1wiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtsaW5rQ2xhc3Nlc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFMaW5rZWRpbiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkxpbmtlZEluPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhyZWY9XCIjXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2xpbmtDbGFzc2VzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVhUd2l0dGVyIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+WCAvIFR3aXR0ZXI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgdGV4dC1zbSB0ZXh0LXppbmMtNTAwIHNtOnRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICDCqSAyMDI2IFN5bmFwc2UgSUEuIFRvZG9zIG9zIGRpcmVpdG9zIHJlc2VydmFkb3MuXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZm9vdGVyPlxyXG4gICAgKVxyXG59Il19