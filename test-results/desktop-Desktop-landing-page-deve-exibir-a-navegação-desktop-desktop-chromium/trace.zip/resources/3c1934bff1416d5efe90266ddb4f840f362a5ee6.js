import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sections/ShowcaseSection.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=12888fd9";
import { useAutoRotate } from "/src/hooks/useAutoRotate.js";
import { showcases } from "/src/data/landingData.js";
var _jsxFileName = "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/ShowcaseSection.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12888fd9";
var _s = $RefreshSig$();
export default function ShowcaseSection() {
	_s();
	const [activeShowcase, setActiveShowcase] = useState(0);
	useAutoRotate(setActiveShowcase, showcases.length, 3600);
	const showcase = showcases[activeShowcase];
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "showcase",
		"data-reveal": true,
		className: "scroll-mt-28 reveal-up",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "mb-8 max-w-3xl",
			children: [/* @__PURE__ */ _jsxDEV("h2", {
				className: "mb-4 text-2xl font-semibold md:text-3xl",
				children: "Veja a plataforma em ação"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 17
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-zinc-300",
				children: "Conheça alguns dos principais módulos da plataforma e descubra como eles ajudam equipes a automatizar processos, monitorar operações e tomar decisões baseadas em dados."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 17
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 18,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col gap-6 lg:grid lg:grid-cols-[260px_minmax(0,1fr)] xl:grid-cols-[300px_minmax(0,1fr)]",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex justify-around gap-3 overflow-x-auto pb-2 lg:flex lg:flex-col lg:justify-center lg:gap-3 lg:overflow-visible lg:pb-0",
				children: showcases.map((item, index) => /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => setActiveShowcase(index),
					className: `group flex h-16 shrink-0 items-center justify-center rounded-xl border p-4 transition-all duration-300 md:gap-2 lg:min-h-28 lg:w-full lg:justify-start lg:gap-4 ${activeShowcase === index ? "border-blue-400 bg-blue-500/10" : "border-zinc-800 bg-zinc-900/40 hover:border-blue-400/40"}`,
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-blue-500/10 text-blue-300",
						children: /* @__PURE__ */ _jsxDEV(item.icon, {
							className: "text-xl",
							"aria-hidden": "true"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 42,
							columnNumber: 33
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 29
					}, this), /* @__PURE__ */ _jsxDEV("h3", {
						className: "hidden font-semibold md:text-sm md:block lg:text-base",
						children: item.title
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 45,
						columnNumber: 29
					}, this)]
				}, item.title, true, {
					fileName: _jsxFileName,
					lineNumber: 31,
					columnNumber: 25
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 17
			}, this), /* @__PURE__ */ _jsxDEV("article", {
				className: "flex min-h-100 md:min-h-80 lg:h-auto flex-col justify-between overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900/40 p-6",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mb-4 flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-blue-500/10 text-blue-300",
						children: /* @__PURE__ */ _jsxDEV(showcase.icon, {
							className: "text-3xl",
							"aria-hidden": "true"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 55,
							columnNumber: 29
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 25
					}, this),
					/* @__PURE__ */ _jsxDEV("h3", {
						className: "mb-3 text-2xl font-bold",
						children: showcase.title
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 58,
						columnNumber: 25
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "max-w-3xl leading-relaxed text-zinc-300",
						children: showcase.description
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 25
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "mt-6 rounded-xl border border-blue-400/20 bg-blue-500/10 p-4",
					children: [/* @__PURE__ */ _jsxDEV("p", {
						className: "text-sm uppercase tracking-widest text-blue-300",
						children: "Resultado"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 25
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "mt-1 text-2xl font-bold text-white",
						children: showcase.metric
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 25
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 67,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 17
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 13
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 9
	}, this);
}
_s(ShowcaseSection, "2MdciblQFJnjK8lJUk78VvkICwk=", false, function() {
	return [useAutoRotate];
});
_c = ShowcaseSection;
var _c;
$RefreshReg$(_c, "ShowcaseSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/sections/ShowcaseSection.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/ShowcaseSection.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/ShowcaseSection.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/ShowcaseSection.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxpQkFBaUI7Ozs7QUFFMUIsZUFBZSxTQUFTLGtCQUFrQjs7Q0FDdEMsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxDQUFDO0NBRXRELGNBQWMsbUJBQW1CLFVBQVUsUUFBUSxJQUFJO0NBRXZELE1BQU0sV0FBVyxVQUFVO0NBRTNCLE9BQ0ksd0JBQUMsV0FBRDtFQUNJLElBQUc7RUFDSDtFQUNBLFdBQVU7WUFIZCxDQUtJLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDSSx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUEwQztHQUVwRDs7OzthQUVKLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQWdCO0dBRTFCOzs7O1dBQ0Y7Ozs7O1lBRUwsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNJLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1YsVUFBVSxLQUFLLE1BQU0sVUFDbEIsd0JBQUMsVUFBRDtLQUVJLE1BQUs7S0FDTCxlQUFlLGtCQUFrQixLQUFLO0tBQ3RDLFdBQVcsbUtBQ1AsbUJBQW1CLFFBQ2IsbUNBQ0E7ZUFQZCxDQVVJLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNYLHdCQUFDLEtBQUssTUFBTjtPQUFXLFdBQVU7T0FBVSxlQUFZO01BQVE7Ozs7O0tBQ2xEOzs7O2VBRUwsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQ1QsS0FBSztLQUNOOzs7O2FBQ0E7T0FoQkMsS0FBSzs7OztXQWdCTixDQUNYO0dBQ0E7Ozs7YUFFTCx3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUFuQixDQUNJLHdCQUFDLE9BQUQ7S0FDSSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDWCx3QkFBQyxTQUFTLE1BQVY7T0FBZSxXQUFVO09BQVcsZUFBWTtNQUFROzs7OztLQUN2RDs7Ozs7S0FFTCx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFDVCxTQUFTO0tBQ1Y7Ozs7O0tBRUosd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQ1IsU0FBUztLQUNYOzs7OztJQUNGOzs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNJLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFrRDtLQUU1RDs7OztlQUVILHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUNSLFNBQVM7S0FDWDs7OzthQUNGOzs7OztZQUNBOzs7OztXQUNSOzs7OztVQUNBOzs7Ozs7QUFFakIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU2hvd2Nhc2VTZWN0aW9uLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VBdXRvUm90YXRlIH0gZnJvbSBcIi4uLy4uL2hvb2tzL3VzZUF1dG9Sb3RhdGVcIjtcclxuaW1wb3J0IHsgc2hvd2Nhc2VzIH0gZnJvbSBcIi4uLy4uL2RhdGEvbGFuZGluZ0RhdGFcIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNob3djYXNlU2VjdGlvbigpIHtcclxuICAgIGNvbnN0IFthY3RpdmVTaG93Y2FzZSwgc2V0QWN0aXZlU2hvd2Nhc2VdID0gdXNlU3RhdGUoMCk7XHJcblxyXG4gICAgdXNlQXV0b1JvdGF0ZShzZXRBY3RpdmVTaG93Y2FzZSwgc2hvd2Nhc2VzLmxlbmd0aCwgMzYwMCk7XHJcblxyXG4gICAgY29uc3Qgc2hvd2Nhc2UgPSBzaG93Y2FzZXNbYWN0aXZlU2hvd2Nhc2VdO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPHNlY3Rpb25cclxuICAgICAgICAgICAgaWQ9XCJzaG93Y2FzZVwiXHJcbiAgICAgICAgICAgIGRhdGEtcmV2ZWFsXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInNjcm9sbC1tdC0yOCByZXZlYWwtdXBcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04IG1heC13LTN4bFwiPlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtZDp0ZXh0LTN4bFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFZlamEgYSBwbGF0YWZvcm1hIGVtIGHDp8Ojb1xyXG4gICAgICAgICAgICAgICAgPC9oMj5cclxuXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXppbmMtMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgQ29uaGXDp2EgYWxndW5zIGRvcyBwcmluY2lwYWlzIG3Ds2R1bG9zIGRhIHBsYXRhZm9ybWEgZSBkZXNjdWJyYSBjb21vIGVsZXMgYWp1ZGFtIGVxdWlwZXMgYSBhdXRvbWF0aXphciBwcm9jZXNzb3MsIG1vbml0b3JhciBvcGVyYcOnw7VlcyBlIHRvbWFyIGRlY2lzw7VlcyBiYXNlYWRhcyBlbSBkYWRvcy5cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTYgbGc6Z3JpZCBsZzpncmlkLWNvbHMtWzI2MHB4X21pbm1heCgwLDFmcildIHhsOmdyaWQtY29scy1bMzAwcHhfbWlubWF4KDAsMWZyKV1cIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWFyb3VuZCBnYXAtMyBvdmVyZmxvdy14LWF1dG8gcGItMiBsZzpmbGV4IGxnOmZsZXgtY29sIGxnOmp1c3RpZnktY2VudGVyIGxnOmdhcC0zIGxnOm92ZXJmbG93LXZpc2libGUgbGc6cGItMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtzaG93Y2FzZXMubWFwKChpdGVtLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0udGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVNob3djYXNlKGluZGV4KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGdyb3VwIGZsZXggaC0xNiBzaHJpbmstMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCBib3JkZXIgcC00IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBtZDpnYXAtMiBsZzptaW4taC0yOCBsZzp3LWZ1bGwgbGc6anVzdGlmeS1zdGFydCBsZzpnYXAtNCAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjdGl2ZVNob3djYXNlID09PSBpbmRleFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLWJsdWUtNDAwIGJnLWJsdWUtNTAwLzEwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJvcmRlci16aW5jLTgwMCBiZy16aW5jLTkwMC80MCBob3Zlcjpib3JkZXItYmx1ZS00MDAvNDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC0xMCB3LTEwIHNocmluay0wIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWxnIGJnLWJsdWUtNTAwLzEwIHRleHQtYmx1ZS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aXRlbS5pY29uIGNsYXNzTmFtZT1cInRleHQteGxcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImhpZGRlbiBmb250LXNlbWlib2xkIG1kOnRleHQtc20gbWQ6YmxvY2sgbGc6dGV4dC1iYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxhcnRpY2xlIGNsYXNzTmFtZT1cImZsZXggbWluLWgtMTAwIG1kOm1pbi1oLTgwIGxnOmgtYXV0byBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItemluYy04MDAgYmctemluYy05MDAvNDAgcC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00IGZsZXggaC0xMCB3LTEwIHNocmluay0wIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWxnIGJnLWJsdWUtNTAwLzEwIHRleHQtYmx1ZS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzaG93Y2FzZS5pY29uIGNsYXNzTmFtZT1cInRleHQtM3hsXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItMyB0ZXh0LTJ4bCBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzaG93Y2FzZS50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm1heC13LTN4bCBsZWFkaW5nLXJlbGF4ZWQgdGV4dC16aW5jLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3Nob3djYXNlLmRlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYmx1ZS00MDAvMjAgYmctYmx1ZS01MDAvMTAgcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LWJsdWUtMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZXN1bHRhZG9cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3Nob3djYXNlLm1ldHJpY31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9hcnRpY2xlPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICApO1xyXG59Il19