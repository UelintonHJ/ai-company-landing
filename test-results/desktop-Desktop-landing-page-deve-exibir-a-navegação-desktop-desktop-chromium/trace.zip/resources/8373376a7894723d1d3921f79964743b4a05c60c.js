import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sections/IntegrationsSection.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { integrations } from "/src/data/landingData.js";
var _jsxFileName = "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/IntegrationsSection.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12888fd9";
export default function IntegrationsSection() {
	return /* @__PURE__ */ _jsxDEV("section", {
		"data-reveal": true,
		className: "reveal-up rounded-2xl border border-zinc-800 bg-zinc-900/35 p-8",
		children: [/* @__PURE__ */ _jsxDEV("h2", {
			className: "mb-8 text-2xl font-semibold md:text-3xl text-center md:text-start",
			children: "Construído para se Integrar à Sua Stack"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 9,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4",
			children: integrations.map((item) => /* @__PURE__ */ _jsxDEV("div", {
				className: "rounded-lg border border-zinc-800 bg-zinc-950/50 px-4 py-3 text-center text-sm font-medium text-zinc-200 transition-all duration-300 hover:-translate-y-1.5 hover:border-blue-400 hover:shadow-lg hover:shadow-blue-400/40",
				children: [/* @__PURE__ */ _jsxDEV(item.icon, {
					className: "w-8 h-8 mx-auto mb-2 text-base text-blue-300",
					"aria-hidden": "true"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 19,
					columnNumber: 25
				}, this), item.name]
			}, item.name, true, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 21
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 13,
			columnNumber: 13
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 5,
		columnNumber: 9
	}, this);
}
_c = IntegrationsSection;
var _c;
$RefreshReg$(_c, "IntegrationsSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/sections/IntegrationsSection.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/IntegrationsSection.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/IntegrationsSection.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/IntegrationsSection.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxvQkFBb0I7OztBQUU3QixlQUFlLFNBQVMsc0JBQXNCO0NBQzFDLE9BQ0ksd0JBQUMsV0FBRDtFQUNJO0VBQ0EsV0FBVTtZQUZkLENBSUksd0JBQUMsTUFBRDtHQUFJLFdBQVU7YUFBb0U7RUFFOUU7Ozs7WUFFSix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNWLGFBQWEsS0FBSyxTQUNmLHdCQUFDLE9BQUQ7SUFFSSxXQUFVO2NBRmQsQ0FJSSx3QkFBQyxLQUFLLE1BQU47S0FBVyxXQUFVO0tBQStDLGVBQVk7SUFBUTs7OztjQUN2RixLQUFLLElBQ0w7TUFMSSxLQUFLOzs7O1VBS1QsQ0FDUjtFQUNBOzs7O1VBQ0E7Ozs7OztBQUVqQiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJJbnRlZ3JhdGlvbnNTZWN0aW9uLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBpbnRlZ3JhdGlvbnMgfSBmcm9tIFwiLi4vLi4vZGF0YS9sYW5kaW5nRGF0YVwiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSW50ZWdyYXRpb25zU2VjdGlvbigpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPHNlY3Rpb25cclxuICAgICAgICAgICAgZGF0YS1yZXZlYWxcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicmV2ZWFsLXVwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItemluYy04MDAgYmctemluYy05MDAvMzUgcC04XCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJtYi04IHRleHQtMnhsIGZvbnQtc2VtaWJvbGQgbWQ6dGV4dC0zeGwgdGV4dC1jZW50ZXIgbWQ6dGV4dC1zdGFydFwiPlxyXG4gICAgICAgICAgICAgICAgQ29uc3RydcOtZG8gcGFyYSBzZSBJbnRlZ3JhciDDoCBTdWEgU3RhY2tcclxuICAgICAgICAgICAgPC9oMj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtNCBzbTpncmlkLWNvbHMtMyBtZDpncmlkLWNvbHMtNFwiPlxyXG4gICAgICAgICAgICAgICAge2ludGVncmF0aW9ucy5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJvcmRlciBib3JkZXItemluYy04MDAgYmctemluYy05NTAvNTAgcHgtNCBweS0zIHRleHQtY2VudGVyIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC16aW5jLTIwMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgaG92ZXI6LXRyYW5zbGF0ZS15LTEuNSBob3Zlcjpib3JkZXItYmx1ZS00MDAgaG92ZXI6c2hhZG93LWxnIGhvdmVyOnNoYWRvdy1ibHVlLTQwMC80MFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aXRlbS5pY29uIGNsYXNzTmFtZT1cInctOCBoLTggbXgtYXV0byBtYi0yIHRleHQtYmFzZSB0ZXh0LWJsdWUtMzAwXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICApXHJcbn0iXX0=