import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sections/ServicesSection.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { services } from "/src/data/landingData.js";
var _jsxFileName = "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/ServicesSection.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12888fd9";
export default function ServicesSection() {
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "services",
		"data-reveal": true,
		className: "scroll-mt-28 reveal-up",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "mb-8 max-w-3xl",
			children: [/* @__PURE__ */ _jsxDEV("h2", {
				className: "mb-4 text-2xl font-semibold md:text-3xl",
				children: "Soluções de IA para acelerar sua empresa"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 17
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-zinc-300",
				children: "Combine inteligência artificial, automação e análise preditiva para transformar processos complexos em operações mais eficientes."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 17
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 10,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "grid gap-6 md:grid-cols-3",
			children: services.map((item) => /* @__PURE__ */ _jsxDEV("article", {
				className: "group rounded-2xl border border-zinc-800 bg-zinc-900/40 p-6 transition-all duration-300 hover:-translate-y-1 hover:border-blue-400/40 hover:shadow-lg hover:shadow-blue-500/10",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mb-5 flex h-12 w-12 items-center justify-center rounded-xl bg-blue-500/10 text-blue-300 transition-colors duration-300 group-hover:bg-blue-500/20",
						children: /* @__PURE__ */ _jsxDEV(item.icon, {
							className: "text-2xl",
							"aria-hidden": "true"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 27,
							columnNumber: 29
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 26,
						columnNumber: 25
					}, this),
					/* @__PURE__ */ _jsxDEV("h3", {
						className: "mb-3 text-xl font-semibold",
						children: item.name
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 30,
						columnNumber: 25
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "leading-relaxed text-zinc-300",
						children: item.summary
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 25
					}, this)
				]
			}, item.name, true, {
				fileName: _jsxFileName,
				lineNumber: 22,
				columnNumber: 21
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 13
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 5,
		columnNumber: 9
	}, this);
}
_c = ServicesSection;
var _c;
$RefreshReg$(_c, "ServicesSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/sections/ServicesSection.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/ServicesSection.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/ServicesSection.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/ServicesSection.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7OztBQUV6QixlQUFlLFNBQVMsa0JBQWtCO0NBQ3RDLE9BQ0ksd0JBQUMsV0FBRDtFQUNJLElBQUc7RUFDSDtFQUNBLFdBQVU7WUFIZCxDQUtJLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDSSx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUEwQztHQUVwRDs7OzthQUVKLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQWdCO0dBRTFCOzs7O1dBQ0Y7Ozs7O1lBRUwsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDVixTQUFTLEtBQUssU0FDWCx3QkFBQyxXQUFEO0lBRUksV0FBVTtjQUZkO0tBSUksd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1gsd0JBQUMsS0FBSyxNQUFOO09BQVcsV0FBVTtPQUFXLGVBQVk7TUFBUTs7Ozs7S0FDbkQ7Ozs7O0tBRUwsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQ1QsS0FBSztLQUNOOzs7OztLQUVKLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUNSLEtBQUs7S0FDUDs7Ozs7SUFDRTtNQWRBLEtBQUs7Ozs7VUFjTCxDQUNaO0VBQ0E7Ozs7VUFDQTs7Ozs7O0FBRWpCIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlNlcnZpY2VzU2VjdGlvbi5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgc2VydmljZXMgfSBmcm9tIFwiLi4vLi4vZGF0YS9sYW5kaW5nRGF0YVwiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2VydmljZXNTZWN0aW9uKCkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8c2VjdGlvbiBcclxuICAgICAgICAgICAgaWQ9XCJzZXJ2aWNlc1wiXHJcbiAgICAgICAgICAgIGRhdGEtcmV2ZWFsXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInNjcm9sbC1tdC0yOCByZXZlYWwtdXBcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04IG1heC13LTN4bFwiPlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtZDp0ZXh0LTN4bFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFNvbHXDp8O1ZXMgZGUgSUEgcGFyYSBhY2VsZXJhciBzdWEgZW1wcmVzYVxyXG4gICAgICAgICAgICAgICAgPC9oMj5cclxuXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXppbmMtMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgQ29tYmluZSBpbnRlbGlnw6puY2lhIGFydGlmaWNpYWwsIGF1dG9tYcOnw6NvIGUgYW7DoWxpc2UgcHJlZGl0aXZhIHBhcmEgdHJhbnNmb3JtYXIgcHJvY2Vzc29zIGNvbXBsZXhvcyBlbSBvcGVyYcOnw7VlcyBtYWlzIGVmaWNpZW50ZXMuXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC02IG1kOmdyaWQtY29scy0zXCI+XHJcbiAgICAgICAgICAgICAgICB7c2VydmljZXMubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGFydGljbGVcclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpdGVtLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdyb3VwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItemluYy04MDAgYmctemluYy05MDAvNDAgcC02IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBob3ZlcjotdHJhbnNsYXRlLXktMSBob3Zlcjpib3JkZXItYmx1ZS00MDAvNDAgaG92ZXI6c2hhZG93LWxnIGhvdmVyOnNoYWRvdy1ibHVlLTUwMC8xMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTUgZmxleCBoLTEyIHctMTIgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQteGwgYmctYmx1ZS01MDAvMTAgdGV4dC1ibHVlLTMwMCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0zMDAgZ3JvdXAtaG92ZXI6YmctYmx1ZS01MDAvMjBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpdGVtLmljb24gY2xhc3NOYW1lPVwidGV4dC0yeGxcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi0zIHRleHQteGwgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImxlYWRpbmctcmVsYXhlZCB0ZXh0LXppbmMtMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5zdW1tYXJ5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9hcnRpY2xlPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgICk7XHJcbn0iXX0=