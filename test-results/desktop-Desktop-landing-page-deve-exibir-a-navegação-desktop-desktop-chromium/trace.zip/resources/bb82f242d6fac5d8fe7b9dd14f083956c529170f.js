import { n as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-FDOR9p9I.js?v=12888fd9";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=12888fd9";
//#region node_modules/react-icons/lib/iconContext.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var DefaultContext = {
	color: void 0,
	size: void 0,
	className: void 0,
	style: void 0,
	attr: void 0
};
var IconContext = import_react.createContext && /*#__PURE__*/ import_react.createContext(DefaultContext);
//#endregion
//#region node_modules/react-icons/lib/iconBase.mjs
var _excluded = [
	"attr",
	"size",
	"title"
];
function _objectWithoutProperties(e, t) {
	if (null == e) return {};
	var o, r, i = _objectWithoutPropertiesLoose(e, t);
	if (Object.getOwnPropertySymbols) {
		var n = Object.getOwnPropertySymbols(e);
		for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]);
	}
	return i;
}
function _objectWithoutPropertiesLoose(r, e) {
	if (null == r) return {};
	var t = {};
	for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
		if (-1 !== e.indexOf(n)) continue;
		t[n] = r[n];
	}
	return t;
}
function _extends() {
	return _extends = Object.assign ? Object.assign.bind() : function(n) {
		for (var e = 1; e < arguments.length; e++) {
			var t = arguments[e];
			for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
		}
		return n;
	}, _extends.apply(null, arguments);
}
function ownKeys(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
			_defineProperty(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty(e, r, t) {
	return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[r] = t, e;
}
function _toPropertyKey(t) {
	var i = _toPrimitive(t, "string");
	return "symbol" == typeof i ? i : i + "";
}
function _toPrimitive(t, r) {
	if ("object" != typeof t || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != typeof i) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function Tree2Element(tree) {
	return tree && tree.map((node, i) => /*#__PURE__*/ import_react.createElement(node.tag, _objectSpread({ key: i }, node.attr), Tree2Element(node.child)));
}
function GenIcon(data) {
	return (props) => /*#__PURE__*/ import_react.createElement(IconBase, _extends({ attr: _objectSpread({}, data.attr) }, props), Tree2Element(data.child));
}
function IconBase(props) {
	var elem = (conf) => {
		var attr = props.attr, size = props.size, title = props.title, svgProps = _objectWithoutProperties(props, _excluded);
		var computedSize = size || conf.size || "1em";
		var className;
		if (conf.className) className = conf.className;
		if (props.className) className = (className ? className + " " : "") + props.className;
		return /*#__PURE__*/ import_react.createElement("svg", _extends({
			stroke: "currentColor",
			fill: "currentColor",
			strokeWidth: "0"
		}, conf.attr, attr, svgProps, {
			className,
			style: _objectSpread(_objectSpread({ color: props.color || conf.color }, conf.style), props.style),
			height: computedSize,
			width: computedSize,
			xmlns: "http://www.w3.org/2000/svg"
		}), title && /*#__PURE__*/ import_react.createElement("title", null, title), props.children);
	};
	return IconContext !== void 0 ? /*#__PURE__*/ import_react.createElement(IconContext.Consumer, null, (conf) => elem(conf)) : elem(DefaultContext);
}
//#endregion
export { GenIcon as t };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaWNvbkJhc2UtREU3Z3VGRXUuanMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiLi4vLi4vcmVhY3QtaWNvbnMvbGliL2ljb25Db250ZXh0Lm1qcyIsIi4uLy4uL3JlYWN0LWljb25zL2xpYi9pY29uQmFzZS5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuZXhwb3J0IHZhciBEZWZhdWx0Q29udGV4dCA9IHtcbiAgY29sb3I6IHVuZGVmaW5lZCxcbiAgc2l6ZTogdW5kZWZpbmVkLFxuICBjbGFzc05hbWU6IHVuZGVmaW5lZCxcbiAgc3R5bGU6IHVuZGVmaW5lZCxcbiAgYXR0cjogdW5kZWZpbmVkXG59O1xuZXhwb3J0IHZhciBJY29uQ29udGV4dCA9IFJlYWN0LmNyZWF0ZUNvbnRleHQgJiYgLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQoRGVmYXVsdENvbnRleHQpOyIsInZhciBfZXhjbHVkZWQgPSBbXCJhdHRyXCIsIFwic2l6ZVwiLCBcInRpdGxlXCJdO1xuZnVuY3Rpb24gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzKGUsIHQpIHsgaWYgKG51bGwgPT0gZSkgcmV0dXJuIHt9OyB2YXIgbywgciwgaSA9IF9vYmplY3RXaXRob3V0UHJvcGVydGllc0xvb3NlKGUsIHQpOyBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scykgeyB2YXIgbiA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMoZSk7IGZvciAociA9IDA7IHIgPCBuLmxlbmd0aDsgcisrKSBvID0gbltyXSwgLTEgPT09IHQuaW5kZXhPZihvKSAmJiB7fS5wcm9wZXJ0eUlzRW51bWVyYWJsZS5jYWxsKGUsIG8pICYmIChpW29dID0gZVtvXSk7IH0gcmV0dXJuIGk7IH1cbmZ1bmN0aW9uIF9vYmplY3RXaXRob3V0UHJvcGVydGllc0xvb3NlKHIsIGUpIHsgaWYgKG51bGwgPT0gcikgcmV0dXJuIHt9OyB2YXIgdCA9IHt9OyBmb3IgKHZhciBuIGluIHIpIGlmICh7fS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHIsIG4pKSB7IGlmICgtMSAhPT0gZS5pbmRleE9mKG4pKSBjb250aW51ZTsgdFtuXSA9IHJbbl07IH0gcmV0dXJuIHQ7IH1cbmZ1bmN0aW9uIF9leHRlbmRzKCkgeyByZXR1cm4gX2V4dGVuZHMgPSBPYmplY3QuYXNzaWduID8gT2JqZWN0LmFzc2lnbi5iaW5kKCkgOiBmdW5jdGlvbiAobikgeyBmb3IgKHZhciBlID0gMTsgZSA8IGFyZ3VtZW50cy5sZW5ndGg7IGUrKykgeyB2YXIgdCA9IGFyZ3VtZW50c1tlXTsgZm9yICh2YXIgciBpbiB0KSAoe30pLmhhc093blByb3BlcnR5LmNhbGwodCwgcikgJiYgKG5bcl0gPSB0W3JdKTsgfSByZXR1cm4gbjsgfSwgX2V4dGVuZHMuYXBwbHkobnVsbCwgYXJndW1lbnRzKTsgfVxuZnVuY3Rpb24gb3duS2V5cyhlLCByKSB7IHZhciB0ID0gT2JqZWN0LmtleXMoZSk7IGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7IHZhciBvID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhlKTsgciAmJiAobyA9IG8uZmlsdGVyKGZ1bmN0aW9uIChyKSB7IHJldHVybiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKGUsIHIpLmVudW1lcmFibGU7IH0pKSwgdC5wdXNoLmFwcGx5KHQsIG8pOyB9IHJldHVybiB0OyB9XG5mdW5jdGlvbiBfb2JqZWN0U3ByZWFkKGUpIHsgZm9yICh2YXIgciA9IDE7IHIgPCBhcmd1bWVudHMubGVuZ3RoOyByKyspIHsgdmFyIHQgPSBudWxsICE9IGFyZ3VtZW50c1tyXSA/IGFyZ3VtZW50c1tyXSA6IHt9OyByICUgMiA/IG93bktleXMoT2JqZWN0KHQpLCAhMCkuZm9yRWFjaChmdW5jdGlvbiAocikgeyBfZGVmaW5lUHJvcGVydHkoZSwgciwgdFtyXSk7IH0pIDogT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnMgPyBPYmplY3QuZGVmaW5lUHJvcGVydGllcyhlLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyh0KSkgOiBvd25LZXlzKE9iamVjdCh0KSkuZm9yRWFjaChmdW5jdGlvbiAocikgeyBPYmplY3QuZGVmaW5lUHJvcGVydHkoZSwgciwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcih0LCByKSk7IH0pOyB9IHJldHVybiBlOyB9XG5mdW5jdGlvbiBfZGVmaW5lUHJvcGVydHkoZSwgciwgdCkgeyByZXR1cm4gKHIgPSBfdG9Qcm9wZXJ0eUtleShyKSkgaW4gZSA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCB7IHZhbHVlOiB0LCBlbnVtZXJhYmxlOiAhMCwgY29uZmlndXJhYmxlOiAhMCwgd3JpdGFibGU6ICEwIH0pIDogZVtyXSA9IHQsIGU7IH1cbmZ1bmN0aW9uIF90b1Byb3BlcnR5S2V5KHQpIHsgdmFyIGkgPSBfdG9QcmltaXRpdmUodCwgXCJzdHJpbmdcIik7IHJldHVybiBcInN5bWJvbFwiID09IHR5cGVvZiBpID8gaSA6IGkgKyBcIlwiOyB9XG5mdW5jdGlvbiBfdG9QcmltaXRpdmUodCwgcikgeyBpZiAoXCJvYmplY3RcIiAhPSB0eXBlb2YgdCB8fCAhdCkgcmV0dXJuIHQ7IHZhciBlID0gdFtTeW1ib2wudG9QcmltaXRpdmVdOyBpZiAodm9pZCAwICE9PSBlKSB7IHZhciBpID0gZS5jYWxsKHQsIHIgfHwgXCJkZWZhdWx0XCIpOyBpZiAoXCJvYmplY3RcIiAhPSB0eXBlb2YgaSkgcmV0dXJuIGk7IHRocm93IG5ldyBUeXBlRXJyb3IoXCJAQHRvUHJpbWl0aXZlIG11c3QgcmV0dXJuIGEgcHJpbWl0aXZlIHZhbHVlLlwiKTsgfSByZXR1cm4gKFwic3RyaW5nXCIgPT09IHIgPyBTdHJpbmcgOiBOdW1iZXIpKHQpOyB9XG5pbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBJY29uQ29udGV4dCwgRGVmYXVsdENvbnRleHQgfSBmcm9tIFwiLi9pY29uQ29udGV4dC5tanNcIjtcbmZ1bmN0aW9uIFRyZWUyRWxlbWVudCh0cmVlKSB7XG4gIHJldHVybiB0cmVlICYmIHRyZWUubWFwKChub2RlLCBpKSA9PiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChub2RlLnRhZywgX29iamVjdFNwcmVhZCh7XG4gICAga2V5OiBpXG4gIH0sIG5vZGUuYXR0ciksIFRyZWUyRWxlbWVudChub2RlLmNoaWxkKSkpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIEdlbkljb24oZGF0YSkge1xuICByZXR1cm4gcHJvcHMgPT4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoSWNvbkJhc2UsIF9leHRlbmRzKHtcbiAgICBhdHRyOiBfb2JqZWN0U3ByZWFkKHt9LCBkYXRhLmF0dHIpXG4gIH0sIHByb3BzKSwgVHJlZTJFbGVtZW50KGRhdGEuY2hpbGQpKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBJY29uQmFzZShwcm9wcykge1xuICB2YXIgZWxlbSA9IGNvbmYgPT4ge1xuICAgIHZhciBhdHRyID0gcHJvcHMuYXR0cixcbiAgICAgIHNpemUgPSBwcm9wcy5zaXplLFxuICAgICAgdGl0bGUgPSBwcm9wcy50aXRsZSxcbiAgICAgIHN2Z1Byb3BzID0gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzKHByb3BzLCBfZXhjbHVkZWQpO1xuICAgIHZhciBjb21wdXRlZFNpemUgPSBzaXplIHx8IGNvbmYuc2l6ZSB8fCBcIjFlbVwiO1xuICAgIHZhciBjbGFzc05hbWU7XG4gICAgaWYgKGNvbmYuY2xhc3NOYW1lKSBjbGFzc05hbWUgPSBjb25mLmNsYXNzTmFtZTtcbiAgICBpZiAocHJvcHMuY2xhc3NOYW1lKSBjbGFzc05hbWUgPSAoY2xhc3NOYW1lID8gY2xhc3NOYW1lICsgXCIgXCIgOiBcIlwiKSArIHByb3BzLmNsYXNzTmFtZTtcbiAgICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoXCJzdmdcIiwgX2V4dGVuZHMoe1xuICAgICAgc3Ryb2tlOiBcImN1cnJlbnRDb2xvclwiLFxuICAgICAgZmlsbDogXCJjdXJyZW50Q29sb3JcIixcbiAgICAgIHN0cm9rZVdpZHRoOiBcIjBcIlxuICAgIH0sIGNvbmYuYXR0ciwgYXR0ciwgc3ZnUHJvcHMsIHtcbiAgICAgIGNsYXNzTmFtZTogY2xhc3NOYW1lLFxuICAgICAgc3R5bGU6IF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7XG4gICAgICAgIGNvbG9yOiBwcm9wcy5jb2xvciB8fCBjb25mLmNvbG9yXG4gICAgICB9LCBjb25mLnN0eWxlKSwgcHJvcHMuc3R5bGUpLFxuICAgICAgaGVpZ2h0OiBjb21wdXRlZFNpemUsXG4gICAgICB3aWR0aDogY29tcHV0ZWRTaXplLFxuICAgICAgeG1sbnM6IFwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxuICAgIH0pLCB0aXRsZSAmJiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChcInRpdGxlXCIsIG51bGwsIHRpdGxlKSwgcHJvcHMuY2hpbGRyZW4pO1xuICB9O1xuICByZXR1cm4gSWNvbkNvbnRleHQgIT09IHVuZGVmaW5lZCA/IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KEljb25Db250ZXh0LkNvbnN1bWVyLCBudWxsLCBjb25mID0+IGVsZW0oY29uZikpIDogZWxlbShEZWZhdWx0Q29udGV4dCk7XG59Il0sIm1hcHBpbmdzIjoiOzs7O0FBQ0EsSUFBVyxpQkFBaUI7Q0FDMUIsT0FBTyxLQUFBO0NBQ1AsTUFBTSxLQUFBO0NBQ04sV0FBVyxLQUFBO0NBQ1gsT0FBTyxLQUFBO0NBQ1AsTUFBTSxLQUFBO0FBQ1I7QUFDQSxJQUFXLGNBQUEsYUFBb0IsaUJBQThCLDJCQUFNLGNBQWMsY0FBYzs7O0FDUi9GLElBQUksWUFBWTtDQUFDO0NBQVE7Q0FBUTtBQUFPO0FBQ3hDLFNBQVMseUJBQXlCLEdBQUcsR0FBRztDQUFFLElBQUksUUFBUSxHQUFHLE9BQU8sQ0FBQztDQUFHLElBQUksR0FBRyxHQUFHLElBQUksOEJBQThCLEdBQUcsQ0FBQztDQUFHLElBQUksT0FBTyx1QkFBdUI7RUFBRSxJQUFJLElBQUksT0FBTyxzQkFBc0IsQ0FBQztFQUFHLEtBQUssSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLEtBQUssSUFBSSxFQUFFLElBQUksT0FBTyxFQUFFLFFBQVEsQ0FBQyxLQUFLLENBQUMsRUFBRSxxQkFBcUIsS0FBSyxHQUFHLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRTtDQUFLO0NBQUUsT0FBTztBQUFHO0FBQ3JVLFNBQVMsOEJBQThCLEdBQUcsR0FBRztDQUFFLElBQUksUUFBUSxHQUFHLE9BQU8sQ0FBQztDQUFHLElBQUksSUFBSSxDQUFDO0NBQUcsS0FBSyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsRUFBRSxlQUFlLEtBQUssR0FBRyxDQUFDLEdBQUc7RUFBRSxJQUFJLE9BQU8sRUFBRSxRQUFRLENBQUMsR0FBRztFQUFVLEVBQUUsS0FBSyxFQUFFO0NBQUk7Q0FBRSxPQUFPO0FBQUc7QUFDdE0sU0FBUyxXQUFXO0NBQUUsT0FBTyxXQUFXLE9BQU8sU0FBUyxPQUFPLE9BQU8sS0FBSyxJQUFJLFNBQVUsR0FBRztFQUFFLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxVQUFVLFFBQVEsS0FBSztHQUFFLElBQUksSUFBSSxVQUFVO0dBQUksS0FBSyxJQUFJLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBQSxDQUFHLGVBQWUsS0FBSyxHQUFHLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRTtFQUFLO0VBQUUsT0FBTztDQUFHLEdBQUcsU0FBUyxNQUFNLE1BQU0sU0FBUztBQUFHO0FBQ25SLFNBQVMsUUFBUSxHQUFHLEdBQUc7Q0FBRSxJQUFJLElBQUksT0FBTyxLQUFLLENBQUM7Q0FBRyxJQUFJLE9BQU8sdUJBQXVCO0VBQUUsSUFBSSxJQUFJLE9BQU8sc0JBQXNCLENBQUM7RUFBRyxNQUFNLElBQUksRUFBRSxPQUFPLFNBQVUsR0FBRztHQUFFLE9BQU8sT0FBTyx5QkFBeUIsR0FBRyxDQUFDLENBQUMsQ0FBQztFQUFZLENBQUMsSUFBSSxFQUFFLEtBQUssTUFBTSxHQUFHLENBQUM7Q0FBRztDQUFFLE9BQU87QUFBRztBQUM5UCxTQUFTLGNBQWMsR0FBRztDQUFFLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxVQUFVLFFBQVEsS0FBSztFQUFFLElBQUksSUFBSSxRQUFRLFVBQVUsS0FBSyxVQUFVLEtBQUssQ0FBQztFQUFHLElBQUksSUFBSSxRQUFRLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxTQUFVLEdBQUc7R0FBRSxnQkFBZ0IsR0FBRyxHQUFHLEVBQUUsRUFBRTtFQUFHLENBQUMsSUFBSSxPQUFPLDRCQUE0QixPQUFPLGlCQUFpQixHQUFHLE9BQU8sMEJBQTBCLENBQUMsQ0FBQyxJQUFJLFFBQVEsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsU0FBVSxHQUFHO0dBQUUsT0FBTyxlQUFlLEdBQUcsR0FBRyxPQUFPLHlCQUF5QixHQUFHLENBQUMsQ0FBQztFQUFHLENBQUM7Q0FBRztDQUFFLE9BQU87QUFBRztBQUN0YixTQUFTLGdCQUFnQixHQUFHLEdBQUcsR0FBRztDQUFFLFFBQVEsSUFBSSxlQUFlLENBQUMsTUFBTSxJQUFJLE9BQU8sZUFBZSxHQUFHLEdBQUc7RUFBRSxPQUFPO0VBQUcsWUFBWSxDQUFDO0VBQUcsY0FBYyxDQUFDO0VBQUcsVUFBVSxDQUFDO0NBQUUsQ0FBQyxJQUFJLEVBQUUsS0FBSyxHQUFHO0FBQUc7QUFDbkwsU0FBUyxlQUFlLEdBQUc7Q0FBRSxJQUFJLElBQUksYUFBYSxHQUFHLFFBQVE7Q0FBRyxPQUFPLFlBQVksT0FBTyxJQUFJLElBQUksSUFBSTtBQUFJO0FBQzFHLFNBQVMsYUFBYSxHQUFHLEdBQUc7Q0FBRSxJQUFJLFlBQVksT0FBTyxLQUFLLENBQUMsR0FBRyxPQUFPO0NBQUcsSUFBSSxJQUFJLEVBQUUsT0FBTztDQUFjLElBQUksS0FBSyxNQUFNLEdBQUc7RUFBRSxJQUFJLElBQUksRUFBRSxLQUFLLEdBQUcsS0FBSyxTQUFTO0VBQUcsSUFBSSxZQUFZLE9BQU8sR0FBRyxPQUFPO0VBQUcsTUFBTSxJQUFJLFVBQVUsOENBQThDO0NBQUc7Q0FBRSxRQUFRLGFBQWEsSUFBSSxTQUFTLE9BQUEsQ0FBUSxDQUFDO0FBQUc7QUFHdlQsU0FBUyxhQUFhLE1BQU07Q0FDMUIsT0FBTyxRQUFRLEtBQUssS0FBSyxNQUFNLE1BQW1CLDJCQUFNLGNBQWMsS0FBSyxLQUFLLGNBQWMsRUFDNUYsS0FBSyxFQUNQLEdBQUcsS0FBSyxJQUFJLEdBQUcsYUFBYSxLQUFLLEtBQUssQ0FBQyxDQUFDO0FBQzFDO0FBQ0EsU0FBZ0IsUUFBUSxNQUFNO0NBQzVCLFFBQU8sVUFBc0IsMkJBQU0sY0FBYyxVQUFVLFNBQVMsRUFDbEUsTUFBTSxjQUFjLENBQUMsR0FBRyxLQUFLLElBQUksRUFDbkMsR0FBRyxLQUFLLEdBQUcsYUFBYSxLQUFLLEtBQUssQ0FBQztBQUNyQztBQUNBLFNBQWdCLFNBQVMsT0FBTztDQUM5QixJQUFJLFFBQU8sU0FBUTtFQUNqQixJQUFJLE9BQU8sTUFBTSxNQUNmLE9BQU8sTUFBTSxNQUNiLFFBQVEsTUFBTSxPQUNkLFdBQVcseUJBQXlCLE9BQU8sU0FBUztFQUN0RCxJQUFJLGVBQWUsUUFBUSxLQUFLLFFBQVE7RUFDeEMsSUFBSTtFQUNKLElBQUksS0FBSyxXQUFXLFlBQVksS0FBSztFQUNyQyxJQUFJLE1BQU0sV0FBVyxhQUFhLFlBQVksWUFBWSxNQUFNLE1BQU0sTUFBTTtFQUM1RSxPQUFvQiwyQkFBTSxjQUFjLE9BQU8sU0FBUztHQUN0RCxRQUFRO0dBQ1IsTUFBTTtHQUNOLGFBQWE7RUFDZixHQUFHLEtBQUssTUFBTSxNQUFNLFVBQVU7R0FDakI7R0FDWCxPQUFPLGNBQWMsY0FBYyxFQUNqQyxPQUFPLE1BQU0sU0FBUyxLQUFLLE1BQzdCLEdBQUcsS0FBSyxLQUFLLEdBQUcsTUFBTSxLQUFLO0dBQzNCLFFBQVE7R0FDUixPQUFPO0dBQ1AsT0FBTztFQUNULENBQUMsR0FBRyxTQUFzQiwyQkFBTSxjQUFjLFNBQVMsTUFBTSxLQUFLLEdBQUcsTUFBTSxRQUFRO0NBQ3JGO0NBQ0EsT0FBTyxnQkFBZ0IsS0FBQSxJQUF5QiwyQkFBTSxjQUFjLFlBQVksVUFBVSxPQUFNLFNBQVEsS0FBSyxJQUFJLENBQUMsSUFBSSxLQUFLLGNBQWM7QUFDM0kiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxXX0=