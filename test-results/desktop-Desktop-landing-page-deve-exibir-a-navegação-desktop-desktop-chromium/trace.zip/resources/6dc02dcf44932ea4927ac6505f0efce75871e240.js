import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/SiteHeader.jsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=12888fd9";
import { FaBars, FaEnvelope, FaXmark } from "/node_modules/.vite/deps/react-icons_fa6.js?v=12888fd9";
import { GiBrain } from "/node_modules/.vite/deps/react-icons_gi.js?v=12888fd9";
var _jsxFileName = "C:/Users/uelin/Desktop/AI Company Landing/src/components/layout/SiteHeader.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12888fd9";
var _s = $RefreshSig$();
const navigation = [
	{
		label: "Recursos",
		href: "#services"
	},
	{
		label: "Preços",
		href: "#pricing"
	},
	{
		label: "Sobre",
		href: "#about"
	},
	{
		label: "FAQ",
		href: "#faq"
	}
];
const FOCUSABLE_SELECTOR = [
	"a[href]",
	"button:not([disabled])",
	"input:not([disabled])",
	"select:not([disabled])",
	"textarea:not([disabled])",
	"[tabindex]:not([tabindex=\"-1\"])"
].join(",");
export default function SiteHeader({ isScrolled }) {
	_s();
	const [menuOpen, setMenuOpen] = useState(false);
	const menuButtonRef = useRef(null);
	const mobileMenuRef = useRef(null);
	const firstMenuLinkRef = useRef(null);
	useEffect(() => {
		if (!menuOpen) {
			return;
		}
		const frame = requestAnimationFrame(() => {
			firstMenuLinkRef.current?.focus();
		});
		return () => {
			cancelAnimationFrame(frame);
		};
	}, [menuOpen]);
	const handleToggleMenu = () => {
		setMenuOpen((previousState) => !previousState);
	};
	const handleCloseMenu = () => {
		setMenuOpen(false);
		requestAnimationFrame(() => {
			menuButtonRef.current?.focus();
		});
	};
	const handleMenuKeyDown = (event) => {
		if (event.key === "Escape") {
			event.preventDefault();
			handleCloseMenu();
			return;
		}
		if (event.key !== "Tab") {
			return;
		}
		const menu = mobileMenuRef.current;
		if (!menu) {
			return;
		}
		const focusableElements = Array.from(menu.querySelectorAll(FOCUSABLE_SELECTOR));
		if (focusableElements.length === 0) {
			return;
		}
		const firstElement = focusableElements[0];
		const lastElement = focusableElements[focusableElements.length - 1];
		if (!event.shiftKey && document.activeElement === lastElement) {
			event.preventDefault();
			firstElement.focus();
			return;
		}
		if (event.shiftKey && document.activeElement === firstElement) {
			event.preventDefault();
			lastElement.focus();
		}
	};
	useEffect(() => {
		const handleResize = () => {
			if (window.innerWidth >= 768 && menuOpen) {
				const menu = mobileMenuRef.current;
				if (menu?.contains(document.activeElement)) {
					document.activeElement?.blur();
				}
				setMenuOpen(false);
			}
		};
		window.addEventListener("resize", handleResize);
		return () => {
			window.removeEventListener("resize", handleResize);
		};
	}, [menuOpen]);
	const navLinkClasses = "relative rounded-sm transition-colors duration-200 hover:text-blue-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 focus-visible:ring-offset-2 focus-visible:ring-offset-zinc-900  ";
	const desktopButtonClasses = "hidden cursor-pointer items-center gap-2 rounded-lg border border-zinc-700 px-5 py-2 text-sm font-medium transition-all duration-200 hover:border-blue-400 hover:bg-blue-500/10 hover:text-blue-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 focus-visible:ring-offset-2 focus-visible:ring-offset-zinc-950 md:inline-flex";
	const mobileButtonClasses = "mt-2 inline-flex items-center justify-center gap-2 rounded-lg bg-blue-500 px-4 p-2.5 font-semibold text-white transition-colors duration-200 hover:bg-blue-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 focus-visible:ring-offset-2 focus-visible:ring-offset-zinc-950";
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("header", {
		className: `fixed left-1/2 top-0 z-50 mt-3 flex w-[min(95%,72rem)] -translate-x-1/2 items-center justify-between rounded-2xl border px-4 py-3 backdrop-blur-xl transition-all duration-300 ${isScrolled ? "border-blue-400/30 bg-black/85 shadow-xl shadow-blue-500/10" : "border-zinc-800/80 bg-zinc-900/70 hover:border-zinc-700"}`,
		children: [
			/* @__PURE__ */ _jsxDEV("a", {
				href: "#top",
				className: "flex items-center gap-3 rounded-sm transition-transform duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 focus-visible:ring-offset-2 focus-visible:ring-offset-zinc-950",
				"aria-label": "Página inicial",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex h-9 w-9 items-center justify-center rounded-sm bg-linear-to-br from-blue-500 to-blue-700 shadow-lg shadow-blue-500/20",
					children: /* @__PURE__ */ _jsxDEV(GiBrain, {
						className: "text-2xl text-white",
						"aria-hidden": "true"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 143,
						columnNumber: 25
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 142,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "text-lg font-semibold tracking-wide",
					children: "Synapse IA"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 149,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 137,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV("nav", {
				"aria-label": "Navegação principal",
				className: "hidden items-center gap-6 text-sm text-zinc-300 md:flex",
				children: navigation.map(({ label, href }) => /* @__PURE__ */ _jsxDEV("a", {
					href,
					className: navLinkClasses,
					children: label
				}, href, false, {
					fileName: _jsxFileName,
					lineNumber: 159,
					columnNumber: 25
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 154,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				ref: menuButtonRef,
				type: "button",
				onClick: handleToggleMenu,
				"aria-label": menuOpen ? "Fechar menu" : "Abrir menu",
				"aria-expanded": menuOpen,
				"aria-controls": "mobile-menu",
				className: "mr-2 inline-flex cursor-pointer items-center gap-2 rounded-lg border border-zinc-700 px-3 py-2 text-sm transition-all duration-200 hover:border-blue-400 hover:text-blue-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 focus-visible:ring-offset-2 focus-visible:ring-offset-zinc-950 md:hidden",
				children: [menuOpen ? /* @__PURE__ */ _jsxDEV(FaXmark, { "aria-hidden": "true" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 179,
					columnNumber: 25
				}, this) : /* @__PURE__ */ _jsxDEV(FaBars, { "aria-hidden": "true" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 181,
					columnNumber: 25
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Menu" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 184,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 169,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV("a", {
				href: "mailto:ola@exemplo.com?subject=Agendamento%20de%20demonstra%C3%A7%C3%A3o",
				className: desktopButtonClasses,
				children: [/* @__PURE__ */ _jsxDEV(FaEnvelope, { "aria-hidden": "true" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 191,
					columnNumber: 21
				}, this), "Agende uma demonstração"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 187,
				columnNumber: 17
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 131,
		columnNumber: 13
	}, this), /* @__PURE__ */ _jsxDEV("div", {
		ref: mobileMenuRef,
		id: "mobile-menu",
		"aria-hidden": !menuOpen,
		inert: !menuOpen,
		onKeyDown: handleMenuKeyDown,
		className: `fixed left-1/2 top-20 z-40 w-[min(95%,72rem)] -translate-x-1/2 rounded-2xl border border-zinc-800 bg-zinc-900/95 p-4 backdrop-blur-xl shadow-xl transition-all duration-300 md:hidden ${menuOpen ? "translate-y-0 opacity-100" : "pointer-events-none -translate-y-4 opacity-0"}`,
		children: /* @__PURE__ */ _jsxDEV("nav", {
			"aria-label": "Navegação mobile",
			className: "flex flex-col  items-center gap-3 text-center text-base font-semibold text-zinc-300",
			children: [navigation.map(({ label, href }, index) => /* @__PURE__ */ _jsxDEV("a", {
				ref: index === 0 ? firstMenuLinkRef : undefined,
				href,
				onClick: handleCloseMenu,
				className: navLinkClasses,
				children: label
			}, href, false, {
				fileName: _jsxFileName,
				lineNumber: 212,
				columnNumber: 25
			}, this)), /* @__PURE__ */ _jsxDEV("a", {
				href: "mailto:ola@exemplo.com?subject=Agendamento%20de%20demonstra%C3%A7%C3%A3o",
				onClick: handleCloseMenu,
				className: mobileButtonClasses,
				children: [/* @__PURE__ */ _jsxDEV(FaEnvelope, { "aria-hidden": "true" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 232,
					columnNumber: 25
				}, this), "Agende uma demonstração"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 227,
				columnNumber: 21
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 207,
			columnNumber: 17
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 196,
		columnNumber: 13
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 130,
		columnNumber: 9
	}, this);
}
_s(SiteHeader, "7AalJG32qN44h8gYGeeM6JXIpNQ=");
_c = SiteHeader;
var _c;
$RefreshReg$(_c, "SiteHeader");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/SiteHeader.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/uelin/Desktop/AI Company Landing/src/components/layout/SiteHeader.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/uelin/Desktop/AI Company Landing/src/components/layout/SiteHeader.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/uelin/Desktop/AI Company Landing/src/components/layout/SiteHeader.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFFBQVEsZ0JBQWdCO0FBQzVDLFNBQVMsUUFBUSxZQUFZLGVBQWU7QUFDNUMsU0FBUyxlQUFlOzs7O0FBRXhCLE1BQU0sYUFBYTtDQUNmO0VBQUUsT0FBTztFQUFZLE1BQU07Q0FBWTtDQUN2QztFQUFFLE9BQU87RUFBVSxNQUFNO0NBQVc7Q0FDcEM7RUFBRSxPQUFPO0VBQVMsTUFBTTtDQUFTO0NBQ2pDO0VBQUUsT0FBTztFQUFPLE1BQU07Q0FBTztBQUNqQztBQUVBLE1BQU0scUJBQXFCO0NBQ3ZCO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtBQUNKLENBQUMsQ0FBQyxLQUFLLEdBQUc7QUFFVixlQUFlLFNBQVMsV0FBVyxFQUFFLGNBQWM7O0NBQy9DLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxLQUFLO0NBRTlDLE1BQU0sZ0JBQWdCLE9BQU8sSUFBSTtDQUNqQyxNQUFNLGdCQUFnQixPQUFPLElBQUk7Q0FDakMsTUFBTSxtQkFBbUIsT0FBTyxJQUFJO0NBRXBDLGdCQUFnQjtFQUNaLElBQUksQ0FBQyxVQUFVO0dBQ1g7RUFDSjtFQUVBLE1BQU0sUUFBUSw0QkFBNEI7R0FDdEMsaUJBQWlCLFNBQVMsTUFBTTtFQUNwQyxDQUFDO0VBRUQsYUFBYTtHQUNULHFCQUFxQixLQUFLO0VBQzlCO0NBQ0osR0FBRyxDQUFDLFFBQVEsQ0FBQztDQUViLE1BQU0seUJBQXlCO0VBQzNCLGFBQWEsa0JBQWtCLENBQUMsYUFBYTtDQUNqRDtDQUVBLE1BQU0sd0JBQXdCO0VBQzFCLFlBQVksS0FBSztFQUVqQiw0QkFBNEI7R0FDeEIsY0FBYyxTQUFTLE1BQU07RUFDakMsQ0FBQztDQUNMO0NBRUEsTUFBTSxxQkFBcUIsVUFBVTtFQUNqQyxJQUFJLE1BQU0sUUFBUSxVQUFVO0dBQ3hCLE1BQU0sZUFBZTtHQUNyQixnQkFBZ0I7R0FDaEI7RUFDSjtFQUVBLElBQUksTUFBTSxRQUFRLE9BQU87R0FDckI7RUFDSjtFQUVBLE1BQU0sT0FBTyxjQUFjO0VBRTNCLElBQUksQ0FBQyxNQUFNO0dBQ1A7RUFDSjtFQUVBLE1BQU0sb0JBQW9CLE1BQU0sS0FDNUIsS0FBSyxpQkFBaUIsa0JBQWtCLENBQzVDO0VBRUEsSUFBSSxrQkFBa0IsV0FBVyxHQUFHO0dBQ2hDO0VBQ0o7RUFFQSxNQUFNLGVBQWUsa0JBQWtCO0VBQ3ZDLE1BQU0sY0FBYyxrQkFBa0Isa0JBQWtCLFNBQVM7RUFFakUsSUFDSSxDQUFDLE1BQU0sWUFDUCxTQUFTLGtCQUFrQixhQUM3QjtHQUNFLE1BQU0sZUFBZTtHQUNyQixhQUFhLE1BQU07R0FDbkI7RUFDSjtFQUVBLElBQ0ksTUFBTSxZQUNOLFNBQVMsa0JBQWtCLGNBQzdCO0dBQ0UsTUFBTSxlQUFlO0dBQ3JCLFlBQVksTUFBTTtFQUN0QjtDQUNKO0NBRUEsZ0JBQWdCO0VBQ1osTUFBTSxxQkFBcUI7R0FDdkIsSUFBSSxPQUFPLGNBQWMsT0FBTyxVQUFVO0lBQ3RDLE1BQU0sT0FBTyxjQUFjO0lBRTNCLElBQUksTUFBTSxTQUFTLFNBQVMsYUFBYSxHQUFHO0tBQ3hDLFNBQVMsZUFBZSxLQUFLO0lBQ2pDO0lBRUEsWUFBWSxLQUFLO0dBQ3JCO0VBQ0o7RUFFQSxPQUFPLGlCQUFpQixVQUFVLFlBQVk7RUFFOUMsYUFBYTtHQUNULE9BQU8sb0JBQW9CLFVBQVUsWUFBWTtFQUNyRDtDQUNKLEdBQUcsQ0FBQyxRQUFRLENBQUM7Q0FFYixNQUFNLGlCQUNGO0NBRUosTUFBTSx1QkFDRjtDQUVKLE1BQU0sc0JBQ0Y7Q0FFSixPQUNJLGdEQUNJLHdCQUFDLFVBQUQ7RUFDSSxXQUFXLGtMQUFrTCxhQUN2TCxnRUFDQTtZQUhWO0dBTUksd0JBQUMsS0FBRDtJQUNJLE1BQUs7SUFDTCxXQUFVO0lBQ1YsY0FBVztjQUhmLENBS0ksd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWCx3QkFBQyxTQUFEO01BQ0ksV0FBVTtNQUNWLGVBQVk7S0FDZjs7Ozs7SUFDQTs7OztjQUVMLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQXNDO0lBRWhEOzs7O1lBQ1A7Ozs7OztHQUVILHdCQUFDLE9BQUQ7SUFDSSxjQUFXO0lBQ1gsV0FBVTtjQUVULFdBQVcsS0FBSyxFQUFFLE9BQU8sV0FDdEIsd0JBQUMsS0FBRDtLQUVVO0tBQ04sV0FBVztlQUVWO0lBQ0YsR0FMTTs7OztXQUtOLENBQ047R0FDQTs7Ozs7R0FFTCx3QkFBQyxVQUFEO0lBQ0ksS0FBSztJQUNMLE1BQUs7SUFDTCxTQUFTO0lBQ1QsY0FBWSxXQUFXLGdCQUFnQjtJQUN2QyxpQkFBZTtJQUNmLGlCQUFjO0lBQ2QsV0FBVTtjQVBkLENBU0ssV0FDRyx3QkFBQyxTQUFELEVBQVMsZUFBWSxPQUFROzs7O2VBRTdCLHdCQUFDLFFBQUQsRUFBUSxlQUFZLE9BQVE7Ozs7Y0FHaEMsd0JBQUMsUUFBRCxZQUFNLE9BQVU7Ozs7WUFDWjs7Ozs7O0dBRVIsd0JBQUMsS0FBRDtJQUNJLE1BQUs7SUFDTCxXQUFXO2NBRmYsQ0FJSSx3QkFBQyxZQUFELEVBQVksZUFBWSxPQUFROzs7O2NBQUMseUJBRWxDOzs7Ozs7RUFDQzs7Ozs7V0FFUix3QkFBQyxPQUFEO0VBQ0ksS0FBSztFQUNMLElBQUc7RUFDSCxlQUFhLENBQUM7RUFDZCxPQUFPLENBQUM7RUFDUixXQUFXO0VBQ1gsV0FBVyx5TEFBeUwsV0FDOUwsOEJBQ0E7WUFHTix3QkFBQyxPQUFEO0dBQ0ksY0FBVztHQUNYLFdBQVU7YUFGZCxDQUlLLFdBQVcsS0FBSyxFQUFFLE9BQU8sUUFBUSxVQUM5Qix3QkFBQyxLQUFEO0lBRUksS0FDSSxVQUFVLElBQ0osbUJBQ0E7SUFFSjtJQUNOLFNBQVM7SUFDVCxXQUFXO2NBRVY7R0FDRixHQVhNOzs7O1VBV04sQ0FDTixHQUVELHdCQUFDLEtBQUQ7SUFDSSxNQUFLO0lBQ0wsU0FBUztJQUNULFdBQVc7Y0FIZixDQUtJLHdCQUFDLFlBQUQsRUFBWSxlQUFZLE9BQVE7Ozs7Y0FBQyx5QkFFbEM7Ozs7O1dBQ0Y7Ozs7OztDQUNKOzs7O1NBQ1A7Ozs7O0FBRVYiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU2l0ZUhlYWRlci5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IEZhQmFycywgRmFFbnZlbG9wZSwgRmFYbWFyayB9IGZyb20gXCJyZWFjdC1pY29ucy9mYTZcIjtcclxuaW1wb3J0IHsgR2lCcmFpbiB9IGZyb20gXCJyZWFjdC1pY29ucy9naVwiO1xyXG5cclxuY29uc3QgbmF2aWdhdGlvbiA9IFtcclxuICAgIHsgbGFiZWw6IFwiUmVjdXJzb3NcIiwgaHJlZjogXCIjc2VydmljZXNcIiB9LFxyXG4gICAgeyBsYWJlbDogXCJQcmXDp29zXCIsIGhyZWY6IFwiI3ByaWNpbmdcIiB9LFxyXG4gICAgeyBsYWJlbDogXCJTb2JyZVwiLCBocmVmOiBcIiNhYm91dFwiIH0sXHJcbiAgICB7IGxhYmVsOiBcIkZBUVwiLCBocmVmOiBcIiNmYXFcIiB9LFxyXG5dO1xyXG5cclxuY29uc3QgRk9DVVNBQkxFX1NFTEVDVE9SID0gW1xyXG4gICAgJ2FbaHJlZl0nLFxyXG4gICAgJ2J1dHRvbjpub3QoW2Rpc2FibGVkXSknLFxyXG4gICAgJ2lucHV0Om5vdChbZGlzYWJsZWRdKScsXHJcbiAgICAnc2VsZWN0Om5vdChbZGlzYWJsZWRdKScsXHJcbiAgICAndGV4dGFyZWE6bm90KFtkaXNhYmxlZF0pJyxcclxuICAgICdbdGFiaW5kZXhdOm5vdChbdGFiaW5kZXg9XCItMVwiXSknLFxyXG5dLmpvaW4oXCIsXCIpO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2l0ZUhlYWRlcih7IGlzU2Nyb2xsZWQgfSkge1xyXG4gICAgY29uc3QgW21lbnVPcGVuLCBzZXRNZW51T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gICAgY29uc3QgbWVudUJ1dHRvblJlZiA9IHVzZVJlZihudWxsKTtcclxuICAgIGNvbnN0IG1vYmlsZU1lbnVSZWYgPSB1c2VSZWYobnVsbCk7XHJcbiAgICBjb25zdCBmaXJzdE1lbnVMaW5rUmVmID0gdXNlUmVmKG51bGwpO1xyXG5cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgaWYgKCFtZW51T3Blbikge1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCBmcmFtZSA9IHJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB7XHJcbiAgICAgICAgICAgIGZpcnN0TWVudUxpbmtSZWYuY3VycmVudD8uZm9jdXMoKTtcclxuICAgICAgICB9KVxyXG5cclxuICAgICAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICAgICAgICBjYW5jZWxBbmltYXRpb25GcmFtZShmcmFtZSk7XHJcbiAgICAgICAgfTtcclxuICAgIH0sIFttZW51T3Blbl0pO1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZVRvZ2dsZU1lbnUgPSAoKSA9PiB7XHJcbiAgICAgICAgc2V0TWVudU9wZW4oKHByZXZpb3VzU3RhdGUpID0+ICFwcmV2aW91c1N0YXRlKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlQ2xvc2VNZW51ID0gKCkgPT4ge1xyXG4gICAgICAgIHNldE1lbnVPcGVuKGZhbHNlKTtcclxuXHJcbiAgICAgICAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpID0+IHtcclxuICAgICAgICAgICAgbWVudUJ1dHRvblJlZi5jdXJyZW50Py5mb2N1cygpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVNZW51S2V5RG93biA9IChldmVudCkgPT4ge1xyXG4gICAgICAgIGlmIChldmVudC5rZXkgPT09IFwiRXNjYXBlXCIpIHtcclxuICAgICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgaGFuZGxlQ2xvc2VNZW51KCk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChldmVudC5rZXkgIT09IFwiVGFiXCIpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgbWVudSA9IG1vYmlsZU1lbnVSZWYuY3VycmVudDtcclxuXHJcbiAgICAgICAgaWYgKCFtZW51KSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IGZvY3VzYWJsZUVsZW1lbnRzID0gQXJyYXkuZnJvbShcclxuICAgICAgICAgICAgbWVudS5xdWVyeVNlbGVjdG9yQWxsKEZPQ1VTQUJMRV9TRUxFQ1RPUilcclxuICAgICAgICApO1xyXG5cclxuICAgICAgICBpZiAoZm9jdXNhYmxlRWxlbWVudHMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IGZpcnN0RWxlbWVudCA9IGZvY3VzYWJsZUVsZW1lbnRzWzBdO1xyXG4gICAgICAgIGNvbnN0IGxhc3RFbGVtZW50ID0gZm9jdXNhYmxlRWxlbWVudHNbZm9jdXNhYmxlRWxlbWVudHMubGVuZ3RoIC0gMV07XHJcblxyXG4gICAgICAgIGlmIChcclxuICAgICAgICAgICAgIWV2ZW50LnNoaWZ0S2V5ICYmXHJcbiAgICAgICAgICAgIGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQgPT09IGxhc3RFbGVtZW50XHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgICAgIGZpcnN0RWxlbWVudC5mb2N1cygpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgIGV2ZW50LnNoaWZ0S2V5ICYmXHJcbiAgICAgICAgICAgIGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQgPT09IGZpcnN0RWxlbWVudFxyXG4gICAgICAgICkge1xyXG4gICAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgICAgICBsYXN0RWxlbWVudC5mb2N1cygpO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBjb25zdCBoYW5kbGVSZXNpemUgPSAoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmICh3aW5kb3cuaW5uZXJXaWR0aCA+PSA3NjggJiYgbWVudU9wZW4pIHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IG1lbnUgPSBtb2JpbGVNZW51UmVmLmN1cnJlbnQ7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKG1lbnU/LmNvbnRhaW5zKGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQuYWN0aXZlRWxlbWVudD8uYmx1cigpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIHNldE1lbnVPcGVuKGZhbHNlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwicmVzaXplXCIsIGhhbmRsZVJlc2l6ZSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgICAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwicmVzaXplXCIsIGhhbmRsZVJlc2l6ZSk7XHJcbiAgICAgICAgfTtcclxuICAgIH0sIFttZW51T3Blbl0pO1xyXG5cclxuICAgIGNvbnN0IG5hdkxpbmtDbGFzc2VzID1cclxuICAgICAgICBcInJlbGF0aXZlIHJvdW5kZWQtc20gdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMjAwIGhvdmVyOnRleHQtYmx1ZS0zMDAgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW5vbmUgZm9jdXMtdmlzaWJsZTpyaW5nLTIgZm9jdXMtdmlzaWJsZTpyaW5nLWJsdWUtNDAwIGZvY3VzLXZpc2libGU6cmluZy1vZmZzZXQtMiBmb2N1cy12aXNpYmxlOnJpbmctb2Zmc2V0LXppbmMtOTAwICBcIjtcclxuXHJcbiAgICBjb25zdCBkZXNrdG9wQnV0dG9uQ2xhc3NlcyA9XHJcbiAgICAgICAgXCJoaWRkZW4gY3Vyc29yLXBvaW50ZXIgaXRlbXMtY2VudGVyIGdhcC0yIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci16aW5jLTcwMCBweC01IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgaG92ZXI6Ym9yZGVyLWJsdWUtNDAwIGhvdmVyOmJnLWJsdWUtNTAwLzEwIGhvdmVyOnRleHQtYmx1ZS0zMDAgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW5vbmUgZm9jdXMtdmlzaWJsZTpyaW5nLTIgZm9jdXMtdmlzaWJsZTpyaW5nLWJsdWUtNDAwIGZvY3VzLXZpc2libGU6cmluZy1vZmZzZXQtMiBmb2N1cy12aXNpYmxlOnJpbmctb2Zmc2V0LXppbmMtOTUwIG1kOmlubGluZS1mbGV4XCI7XHJcblxyXG4gICAgY29uc3QgbW9iaWxlQnV0dG9uQ2xhc3NlcyA9XHJcbiAgICAgICAgXCJtdC0yIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiByb3VuZGVkLWxnIGJnLWJsdWUtNTAwIHB4LTQgcC0yLjUgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMCBob3ZlcjpiZy1ibHVlLTQwMCBmb2N1cy12aXNpYmxlOm91dGxpbmUtbm9uZSBmb2N1cy12aXNpYmxlOnJpbmctMiBmb2N1cy12aXNpYmxlOnJpbmctYmx1ZS00MDAgZm9jdXMtdmlzaWJsZTpyaW5nLW9mZnNldC0yIGZvY3VzLXZpc2libGU6cmluZy1vZmZzZXQtemluYy05NTBcIjtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxoZWFkZXJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZpeGVkIGxlZnQtMS8yIHRvcC0wIHotNTAgbXQtMyBmbGV4IHctW21pbig5NSUsNzJyZW0pXSAtdHJhbnNsYXRlLXgtMS8yIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcm91bmRlZC0yeGwgYm9yZGVyIHB4LTQgcHktMyBiYWNrZHJvcC1ibHVyLXhsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCAke2lzU2Nyb2xsZWRcclxuICAgICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLWJsdWUtNDAwLzMwIGJnLWJsYWNrLzg1IHNoYWRvdy14bCBzaGFkb3ctYmx1ZS01MDAvMTBcIlxyXG4gICAgICAgICAgICAgICAgICAgIDogXCJib3JkZXItemluYy04MDAvODAgYmctemluYy05MDAvNzAgaG92ZXI6Ym9yZGVyLXppbmMtNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgICBocmVmPVwiI3RvcFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcm91bmRlZC1zbSB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0yMDAgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW5vbmUgZm9jdXMtdmlzaWJsZTpyaW5nLTIgZm9jdXMtdmlzaWJsZTpyaW5nLWJsdWUtNDAwIGZvY3VzLXZpc2libGU6cmluZy1vZmZzZXQtMiBmb2N1cy12aXNpYmxlOnJpbmctb2Zmc2V0LXppbmMtOTUwXCJcclxuICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiUMOhZ2luYSBpbmljaWFsXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC05IHctOSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1zbSBiZy1saW5lYXItdG8tYnIgZnJvbS1ibHVlLTUwMCB0by1ibHVlLTcwMCBzaGFkb3ctbGcgc2hhZG93LWJsdWUtNTAwLzIwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxHaUJyYWluXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCB0ZXh0LXdoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtaGlkZGVuPVwidHJ1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0cmFja2luZy13aWRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFN5bmFwc2UgSUFcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2E+XHJcblxyXG4gICAgICAgICAgICAgICAgPG5hdlxyXG4gICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJOYXZlZ2HDp8OjbyBwcmluY2lwYWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlbiBpdGVtcy1jZW50ZXIgZ2FwLTYgdGV4dC1zbSB0ZXh0LXppbmMtMzAwIG1kOmZsZXhcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtuYXZpZ2F0aW9uLm1hcCgoeyBsYWJlbCwgaHJlZiB9KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2hyZWZ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBocmVmPXtocmVmfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtuYXZMaW5rQ2xhc3Nlc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2xhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L25hdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgcmVmPXttZW51QnV0dG9uUmVmfVxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVRvZ2dsZU1lbnV9XHJcbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17bWVudU9wZW4gPyBcIkZlY2hhciBtZW51XCIgOiBcIkFicmlyIG1lbnVcIn1cclxuICAgICAgICAgICAgICAgICAgICBhcmlhLWV4cGFuZGVkPXttZW51T3Blbn1cclxuICAgICAgICAgICAgICAgICAgICBhcmlhLWNvbnRyb2xzPVwibW9iaWxlLW1lbnVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1yLTIgaW5saW5lLWZsZXggY3Vyc29yLXBvaW50ZXIgaXRlbXMtY2VudGVyIGdhcC0yIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci16aW5jLTcwMCBweC0zIHB5LTIgdGV4dC1zbSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgaG92ZXI6Ym9yZGVyLWJsdWUtNDAwIGhvdmVyOnRleHQtYmx1ZS0zMDAgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW5vbmUgZm9jdXMtdmlzaWJsZTpyaW5nLTIgZm9jdXMtdmlzaWJsZTpyaW5nLWJsdWUtNDAwIGZvY3VzLXZpc2libGU6cmluZy1vZmZzZXQtMiBmb2N1cy12aXNpYmxlOnJpbmctb2Zmc2V0LXppbmMtOTUwIG1kOmhpZGRlblwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge21lbnVPcGVuID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8RmFYbWFyayBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxGYUJhcnMgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5NZW51PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgICBocmVmPVwibWFpbHRvOm9sYUBleGVtcGxvLmNvbT9zdWJqZWN0PUFnZW5kYW1lbnRvJTIwZGUlMjBkZW1vbnN0cmElQzMlQTclQzMlQTNvXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Rlc2t0b3BCdXR0b25DbGFzc2VzfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxGYUVudmVsb3BlIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgQWdlbmRlIHVtYSBkZW1vbnN0cmHDp8Ojb1xyXG4gICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICA8L2hlYWRlcj5cclxuXHJcbiAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgIHJlZj17bW9iaWxlTWVudVJlZn1cclxuICAgICAgICAgICAgICAgIGlkPVwibW9iaWxlLW1lbnVcIlxyXG4gICAgICAgICAgICAgICAgYXJpYS1oaWRkZW49eyFtZW51T3Blbn1cclxuICAgICAgICAgICAgICAgIGluZXJ0PXshbWVudU9wZW59XHJcbiAgICAgICAgICAgICAgICBvbktleURvd249e2hhbmRsZU1lbnVLZXlEb3dufVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZml4ZWQgbGVmdC0xLzIgdG9wLTIwIHotNDAgdy1bbWluKDk1JSw3MnJlbSldIC10cmFuc2xhdGUteC0xLzIgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci16aW5jLTgwMCBiZy16aW5jLTkwMC85NSBwLTQgYmFja2Ryb3AtYmx1ci14bCBzaGFkb3cteGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIG1kOmhpZGRlbiAke21lbnVPcGVuXHJcbiAgICAgICAgICAgICAgICAgICAgPyBcInRyYW5zbGF0ZS15LTAgb3BhY2l0eS0xMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIDogXCJwb2ludGVyLWV2ZW50cy1ub25lIC10cmFuc2xhdGUteS00IG9wYWNpdHktMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxuYXZcclxuICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiTmF2ZWdhw6fDo28gbW9iaWxlXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sICBpdGVtcy1jZW50ZXIgZ2FwLTMgdGV4dC1jZW50ZXIgdGV4dC1iYXNlIGZvbnQtc2VtaWJvbGQgdGV4dC16aW5jLTMwMFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge25hdmlnYXRpb24ubWFwKCh7IGxhYmVsLCBocmVmIH0sIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2hyZWZ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWY9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluZGV4ID09PSAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gZmlyc3RNZW51TGlua1JlZlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaHJlZj17aHJlZn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNsb3NlTWVudX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17bmF2TGlua0NsYXNzZXN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBocmVmPVwibWFpbHRvOm9sYUBleGVtcGxvLmNvbT9zdWJqZWN0PUFnZW5kYW1lbnRvJTIwZGUlMjBkZW1vbnN0cmElQzMlQTclQzMlQTNvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xvc2VNZW51fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e21vYmlsZUJ1dHRvbkNsYXNzZXN9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8RmFFbnZlbG9wZSBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBBZ2VuZGUgdW1hIGRlbW9uc3RyYcOnw6NvXHJcbiAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgPC9uYXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvPlxyXG4gICAgKVxyXG59Il19