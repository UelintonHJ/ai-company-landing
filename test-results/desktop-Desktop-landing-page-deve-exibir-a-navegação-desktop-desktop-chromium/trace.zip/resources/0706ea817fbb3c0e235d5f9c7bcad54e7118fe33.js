import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sections/TestimonialsSection.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=12888fd9";
import { FaArrowLeft, FaArrowRight } from "/node_modules/.vite/deps/react-icons_fa.js?v=12888fd9";
import { useAutoRotate } from "/src/hooks/useAutoRotate.js";
import { testimonials } from "/src/data/landingData.js";
var _jsxFileName = "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/TestimonialsSection.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12888fd9";
var _s = $RefreshSig$();
export default function TestimonialsSection() {
	_s();
	const [activeTestimonial, setActiveTestimonial] = useState(0);
	useAutoRotate(setActiveTestimonial, testimonials.length, 4500);
	return /* @__PURE__ */ _jsxDEV("section", {
		"data-reveal": true,
		className: "reveal-up rounded-2xl border border-zinc-800 bg-zinc-900/40 p-8",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mb-6 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-2xl font-semibold md:text-3xl",
					children: "O que dizem os nossos clientes"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 17,
					columnNumber: 17
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => setActiveTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length),
						className: "inline-flex h-9 w-9 items-center justify-center rounded-md border border-zinc-700 text-sm transition hover:border-blue-400",
						"aria-label": "Voltar depoimento",
						children: /* @__PURE__ */ _jsxDEV(FaArrowLeft, { "aria-hidden": "true" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 34,
							columnNumber: 25
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 22,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => setActiveTestimonial((prev) => (prev + 1) % testimonials.length),
						className: "inline-flex h-9 w-9 items-center justify-center rounded-md border border-zinc-700 text-sm transition hover:border-blue-400",
						"aria-label": "Próximo depoimento",
						children: /* @__PURE__ */ _jsxDEV(FaArrowRight, { "aria-hidden": "true" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 47,
							columnNumber: 25
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 37,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 21,
					columnNumber: 17
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 16,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "overflow-hidden",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "flex transition-transform duration-700 ease-out",
					style: { transform: `translateX(-${activeTestimonial * 100}%)` },
					children: testimonials.map((item) => /* @__PURE__ */ _jsxDEV("article", {
						className: "flex min-h-15 min-w-full flex-col rounded-xl border border-zinc-800 bg-zinc-950/50 p-8",
						children: [
							/* @__PURE__ */ _jsxDEV("p", {
								className: "flex-1 mb-6 text-xl leading-relaxed text-zinc-200",
								children: [
									"\"",
									item.quote,
									"\""
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 64,
								columnNumber: 29
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "font-medium text-blue-300",
								children: item.author
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 68,
								columnNumber: 29
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-sm text-zinc-300",
								children: item.role
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 72,
								columnNumber: 29
							}, this)
						]
					}, item.author, true, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 25
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 17
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { children: testimonials.map((item, index) => /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				onClick: () => setActiveTestimonial(index),
				className: `h-2.5 mr-1 rounded-full transition-all ${activeTestimonial === index ? "w-8 bg-blue-300" : "w-2.5 bg-zinc-600"}`,
				"aria-label": `Ir para depoimento ${index + 1}`
			}, item.author, false, {
				fileName: _jsxFileName,
				lineNumber: 82,
				columnNumber: 21
			}, this)) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 9
	}, this);
}
_s(TestimonialsSection, "GnGOYpFGqiqiSq13goPmk33TFzQ=", false, function() {
	return [useAutoRotate];
});
_c = TestimonialsSection;
var _c;
$RefreshReg$(_c, "TestimonialsSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/sections/TestimonialsSection.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/TestimonialsSection.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/TestimonialsSection.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/TestimonialsSection.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxhQUFhLG9CQUFvQjtBQUMxQyxTQUFTLHFCQUFxQjtBQUM5QixTQUFTLG9CQUFvQjs7OztBQUU3QixlQUFlLFNBQVMsc0JBQXNCOztDQUMxQyxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUFTLENBQUM7Q0FFNUQsY0FBYyxzQkFBc0IsYUFBYSxRQUFRLElBQUk7Q0FFN0QsT0FDSSx3QkFBQyxXQUFEO0VBQ0k7RUFDQSxXQUFVO1lBRmQ7R0FJSSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0ksd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBcUM7SUFFL0M7Ozs7Y0FFSix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0ksd0JBQUMsVUFBRDtNQUNJLE1BQUs7TUFDTCxlQUNJLHNCQUNLLFVBQ0ksT0FBTyxJQUFJLGFBQWEsVUFDekIsYUFBYSxNQUNyQjtNQUVKLFdBQVU7TUFDVixjQUFXO2dCQUVYLHdCQUFDLGFBQUQsRUFBYSxlQUFZLE9BQVE7Ozs7O0tBQzdCOzs7O2VBRVIsd0JBQUMsVUFBRDtNQUNJLE1BQUs7TUFDTCxlQUNJLHNCQUNLLFVBQVUsT0FBTyxLQUFLLGFBQWEsTUFDeEM7TUFFSixXQUFVO01BQ1YsY0FBVztnQkFFWCx3QkFBQyxjQUFELEVBQWMsZUFBWSxPQUFROzs7OztLQUM5Qjs7OzthQUNQOzs7OztZQUNKOzs7Ozs7R0FFTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNYLHdCQUFDLE9BQUQ7S0FDSSxXQUFVO0tBQ1YsT0FBTyxFQUNILFdBQVcsZUFBZSxvQkFBb0IsSUFBSSxJQUN0RDtlQUVDLGFBQWEsS0FBSyxTQUNmLHdCQUFDLFdBQUQ7TUFFSSxXQUFVO2dCQUZkO09BSUksd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWI7U0FBaUU7U0FDM0QsS0FBSztTQUFNO1FBQ2Q7Ozs7OztPQUVILHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUNSLEtBQUs7T0FDUDs7Ozs7T0FFSCx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFDUixLQUFLO09BQ1A7Ozs7O01BQ0U7UUFkQSxLQUFLOzs7O1lBY0wsQ0FDWjtJQUNBOzs7OztHQUNKOzs7OztHQUVMLHdCQUFDLE9BQUQsWUFDSyxhQUFhLEtBQUssTUFBTSxVQUNyQix3QkFBQyxVQUFEO0lBQ0ksTUFBSztJQUVMLGVBQWUscUJBQXFCLEtBQUs7SUFDekMsV0FBVywwQ0FDUCxzQkFBc0IsUUFDaEIsb0JBQ0E7SUFFVixjQUFZLHNCQUFzQixRQUFRO0dBQzdDLEdBUlEsS0FBSzs7OztVQVFiLENBQ0osRUFDQTs7Ozs7RUFDQTs7Ozs7O0FBRWpCIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlRlc3RpbW9uaWFsc1NlY3Rpb24uanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCJcclxuaW1wb3J0IHsgRmFBcnJvd0xlZnQsIEZhQXJyb3dSaWdodCB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRvUm90YXRlIH0gZnJvbSBcIi4uLy4uL2hvb2tzL3VzZUF1dG9Sb3RhdGVcIjtcclxuaW1wb3J0IHsgdGVzdGltb25pYWxzIH0gZnJvbSBcIi4uLy4uL2RhdGEvbGFuZGluZ0RhdGFcIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFRlc3RpbW9uaWFsc1NlY3Rpb24oKSB7XHJcbiAgICBjb25zdCBbYWN0aXZlVGVzdGltb25pYWwsIHNldEFjdGl2ZVRlc3RpbW9uaWFsXSA9IHVzZVN0YXRlKDApO1xyXG5cclxuICAgIHVzZUF1dG9Sb3RhdGUoc2V0QWN0aXZlVGVzdGltb25pYWwsIHRlc3RpbW9uaWFscy5sZW5ndGgsIDQ1MDApO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPHNlY3Rpb25cclxuICAgICAgICAgICAgZGF0YS1yZXZlYWxcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicmV2ZWFsLXVwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItemluYy04MDAgYmctemluYy05MDAvNDAgcC04XCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIG1kOnRleHQtM3hsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgTyBxdWUgZGl6ZW0gb3Mgbm9zc29zIGNsaWVudGVzXHJcbiAgICAgICAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmVUZXN0aW1vbmlhbChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAocHJldikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKHByZXYgLSAxICsgdGVzdGltb25pYWxzLmxlbmd0aCkgJVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXN0aW1vbmlhbHMubGVuZ3RoICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGgtOSB3LTkgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci16aW5jLTcwMCB0ZXh0LXNtIHRyYW5zaXRpb24gaG92ZXI6Ym9yZGVyLWJsdWUtNDAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlZvbHRhciBkZXBvaW1lbnRvXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxGYUFycm93TGVmdCBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QWN0aXZlVGVzdGltb25pYWwoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKHByZXYpID0+IChwcmV2ICsgMSkgJSB0ZXN0aW1vbmlhbHMubGVuZ3RoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaC05IHctOSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLXppbmMtNzAwIHRleHQtc20gdHJhbnNpdGlvbiBob3Zlcjpib3JkZXItYmx1ZS00MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiUHLDs3hpbW8gZGVwb2ltZW50b1wiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8RmFBcnJvd1JpZ2h0IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tNzAwIGVhc2Utb3V0XCJcclxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IGB0cmFuc2xhdGVYKC0ke2FjdGl2ZVRlc3RpbW9uaWFsICogMTAwfSUpYCxcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHt0ZXN0aW1vbmlhbHMubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxhcnRpY2xlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0uYXV0aG9yfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBtaW4taC0xNSBtaW4tdy1mdWxsIGZsZXgtY29sIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci16aW5jLTgwMCBiZy16aW5jLTk1MC81MCBwLThcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmbGV4LTEgbWItNiB0ZXh0LXhsIGxlYWRpbmctcmVsYXhlZCB0ZXh0LXppbmMtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJ7aXRlbS5xdW90ZX1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtYmx1ZS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5hdXRob3J9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXppbmMtMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ucm9sZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9hcnRpY2xlPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIHt0ZXN0aW1vbmlhbHMubWFwKChpdGVtLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0uYXV0aG9yfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUZXN0aW1vbmlhbChpbmRleCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGgtMi41IG1yLTEgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tYWxsICR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY3RpdmVUZXN0aW1vbmlhbCA9PT0gaW5kZXhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwidy04IGJnLWJsdWUtMzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwidy0yLjUgYmctemluYy02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YElyIHBhcmEgZGVwb2ltZW50byAke2luZGV4ICsgMX1gfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgKVxyXG59Il19