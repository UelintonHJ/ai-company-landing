import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sections/PricingSection.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=12888fd9";
import { FaCheckCircle } from "/node_modules/.vite/deps/react-icons_fa.js?v=12888fd9";
import { pricing } from "/src/data/landingData.js";
var _jsxFileName = "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/PricingSection.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12888fd9";
var _s = $RefreshSig$();
const contactEmail = "ola@exemplo.com";
export default function PricingSection() {
	_s();
	const [annualBilling, setAnnualBilling] = useState(true);
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "pricing",
		"data-reveal": true,
		className: "scroll-mt-28 reveal-up rounded-2xl border border-zinc-800 bg-zinc-900/30 p-8",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "mb-8 flex flex-wrap items-center justify-center gap-4 md:justify-between",
			children: [/* @__PURE__ */ _jsxDEV("h2", {
				className: "w-full text-center text-2xl font-semibold md:w-auto md:text-left md:text-3xl",
				children: "Melhores Preços Para a Sua Etapa"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 17,
				columnNumber: 17
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "mx-auto rounded-lg border border-zinc-700 p-1 text-sm md:mx-0",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => setAnnualBilling(false),
					className: `rounded-md px-4 py-2 transition-all duration-300 ${annualBilling ? "text-zinc-400" : "bg-zinc-100 text-zinc-900"}`,
					"aria-pressed": !annualBilling,
					children: "Mensal"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 22,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => setAnnualBilling(true),
					className: `rounded-md px-4 py-2 transition-all duration-300 ${annualBilling ? "bg-zinc-400 text-white" : "text-zinc-400"}`,
					"aria-pressed": annualBilling,
					children: "Anual"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 34,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 17
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 16,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "grid gap-6 md:grid-cols-3",
			children: pricing.map((plan) => {
				const emailSubject = encodeURIComponent(`Interesse no plano ${plan.tier}`);
				const contactHref = `mailto:${contactEmail}?subject=${emailSubject};`;
				return /* @__PURE__ */ _jsxDEV("article", {
					className: `flex h-full flex-col rounded-xl border p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl ${plan.popular ? "border-blue-400 bg-blue-400/10 shadow-lg shadow-blue-500/20" : "border-zinc-800 bg-zinc-950/50 hover:border-blue-400/40 hover:shadow-blue-500/10"}`,
					children: [
						/* @__PURE__ */ _jsxDEV("p", {
							className: "mb-2 text-sm text-zinc-400",
							children: plan.tier
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 29
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "mb-3 text-3xl font-bold transition-all duration-300",
							children: [annualBilling ? plan.annual : plan.monthly, plan.monthly !== "Sob consulta" && /* @__PURE__ */ _jsxDEV("span", {
								className: "text-sm text-zinc-400",
								children: "/mês"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 72,
								columnNumber: 37
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 29
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "mb-4 text-zinc-300",
							children: plan.description
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 78,
							columnNumber: 29
						}, this),
						/* @__PURE__ */ _jsxDEV("ul", {
							className: "mb-6 flex-1 space-y-2 text-sm text-zinc-300",
							children: plan.features.map((feature) => /* @__PURE__ */ _jsxDEV("li", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(FaCheckCircle, {
									className: "mt-0.5 text-blue-300",
									"aria-hidden": "true"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 88,
									columnNumber: 41
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: feature }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 89,
									columnNumber: 41
								}, this)]
							}, feature, true, {
								fileName: _jsxFileName,
								lineNumber: 84,
								columnNumber: 37
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 29
						}, this),
						/* @__PURE__ */ _jsxDEV("a", {
							href: contactHref,
							className: "mt-auto block w-full rounded-lg border border-zinc-600 px-4 py-2 text-center font-medium transition hover:border-blue-400 hover:text-blue-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 focus-visible:ring-offset-2 focus-visible:ring-offset-zinc-950",
							children: "Comece"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 94,
							columnNumber: 29
						}, this)
					]
				}, plan.tier, true, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 25
				}, this);
			})
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 48,
			columnNumber: 13
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 11,
		columnNumber: 9
	}, this);
}
_s(PricingSection, "jaxNC3Hw2OiWOu3NLOsVj+BSsUM=");
_c = PricingSection;
var _c;
$RefreshReg$(_c, "PricingSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/sections/PricingSection.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/PricingSection.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/PricingSection.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/PricingSection.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxlQUFlOzs7O0FBRXhCLE1BQU0sZUFBZTtBQUVyQixlQUFlLFNBQVMsaUJBQWlCOztDQUNyQyxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxJQUFJO0NBRXZELE9BQ0ksd0JBQUMsV0FBRDtFQUNJLElBQUc7RUFDSDtFQUNBLFdBQVU7WUFIZCxDQUtJLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDSSx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUErRTtHQUV6Rjs7OzthQUVKLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDSSx3QkFBQyxVQUFEO0tBQ0ksTUFBSztLQUNMLGVBQWUsaUJBQWlCLEtBQUs7S0FDckMsV0FBVyxvREFBb0QsZ0JBQ3JELGtCQUNBO0tBRVYsZ0JBQWMsQ0FBQztlQUNsQjtJQUVPOzs7O2NBRVIsd0JBQUMsVUFBRDtLQUNJLE1BQUs7S0FDTCxlQUFlLGlCQUFpQixJQUFJO0tBQ3BDLFdBQVcsb0RBQW9ELGdCQUN6RCwyQkFDQTtLQUVOLGdCQUFjO2VBQ2pCO0lBRU87Ozs7WUFDUDs7Ozs7V0FDSjs7Ozs7WUFFTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNWLFFBQVEsS0FBSyxTQUFTO0lBQ25CLE1BQU0sZUFBZSxtQkFDakIsc0JBQXNCLEtBQUssTUFDL0I7SUFFQSxNQUFNLGNBQWMsVUFBVSxhQUFhLFdBQVcsYUFBYTtJQUVuRSxPQUNJLHdCQUFDLFdBQUQ7S0FFSSxXQUFXLCtHQUErRyxLQUFLLFVBQ3JILGdFQUNBO2VBSmQ7TUFPSSx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFDUixLQUFLO01BQ1A7Ozs7O01BRUgsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWIsQ0FDSyxnQkFBZ0IsS0FBSyxTQUFTLEtBQUssU0FFbkMsS0FBSyxZQUFZLGtCQUNkLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUF3QjtPQUVsQzs7OztlQUVYOzs7Ozs7TUFFSCx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFDUixLQUFLO01BQ1A7Ozs7O01BRUgsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQ1QsS0FBSyxTQUFTLEtBQUssWUFDaEIsd0JBQUMsTUFBRDtRQUVJLFdBQVU7a0JBRmQsQ0FJSSx3QkFBQyxlQUFEO1NBQWUsV0FBVTtTQUF1QixlQUFZO1FBQVE7Ozs7a0JBQ3BFLHdCQUFDLFFBQUQsWUFBTyxRQUFjOzs7O2dCQUNyQjtVQUxLOzs7O2NBS0wsQ0FDUDtNQUNEOzs7OztNQUVKLHdCQUFDLEtBQUQ7T0FDSSxNQUFNO09BQ04sV0FBVTtpQkFBMlI7TUFFdFM7Ozs7O0tBQ0U7T0F6Q0EsS0FBSzs7OztXQXlDTDtHQUVqQixDQUFDO0VBQ0E7Ozs7VUFDQTs7Ozs7O0FBRWpCIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlByaWNpbmdTZWN0aW9uLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBGYUNoZWNrQ2lyY2xlIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IHByaWNpbmcgfSBmcm9tIFwiLi4vLi4vZGF0YS9sYW5kaW5nRGF0YVwiO1xyXG5cclxuY29uc3QgY29udGFjdEVtYWlsID0gXCJvbGFAZXhlbXBsby5jb21cIlxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUHJpY2luZ1NlY3Rpb24oKSB7XHJcbiAgICBjb25zdCBbYW5udWFsQmlsbGluZywgc2V0QW5udWFsQmlsbGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxzZWN0aW9uXHJcbiAgICAgICAgICAgIGlkPVwicHJpY2luZ1wiXHJcbiAgICAgICAgICAgIGRhdGEtcmV2ZWFsXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInNjcm9sbC1tdC0yOCByZXZlYWwtdXAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci16aW5jLTgwMCBiZy16aW5jLTkwMC8zMCBwLThcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04IGZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtNCBtZDpqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1jZW50ZXIgdGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtZDp3LWF1dG8gbWQ6dGV4dC1sZWZ0IG1kOnRleHQtM3hsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgTWVsaG9yZXMgUHJlw6dvcyBQYXJhIGEgU3VhIEV0YXBhXHJcbiAgICAgICAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXgtYXV0byByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItemluYy03MDAgcC0xIHRleHQtc20gbWQ6bXgtMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFubnVhbEJpbGxpbmcoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Byb3VuZGVkLW1kIHB4LTQgcHktMiB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgJHthbm51YWxCaWxsaW5nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcInRleHQtemluYy00MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy16aW5jLTEwMCB0ZXh0LXppbmMtOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhcmlhLXByZXNzZWQ9eyFhbm51YWxCaWxsaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTWVuc2FsXHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFubnVhbEJpbGxpbmcodHJ1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJvdW5kZWQtbWQgcHgtNCBweS0yIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCAke2FubnVhbEJpbGxpbmdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy16aW5jLTQwMCB0ZXh0LXdoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LXppbmMtNDAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhcmlhLXByZXNzZWQ9e2FubnVhbEJpbGxpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBBbnVhbFxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC02IG1kOmdyaWQtY29scy0zXCI+XHJcbiAgICAgICAgICAgICAgICB7cHJpY2luZy5tYXAoKHBsYW4pID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBlbWFpbFN1YmplY3QgPSBlbmNvZGVVUklDb21wb25lbnQoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGBJbnRlcmVzc2Ugbm8gcGxhbm8gJHtwbGFuLnRpZXJ9YFxyXG4gICAgICAgICAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNvbnRhY3RIcmVmID0gYG1haWx0bzoke2NvbnRhY3RFbWFpbH0/c3ViamVjdD0ke2VtYWlsU3ViamVjdH07YFxyXG5cclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YXJ0aWNsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtwbGFuLnRpZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGgtZnVsbCBmbGV4LWNvbCByb3VuZGVkLXhsIGJvcmRlciBwLTYgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGhvdmVyOi10cmFuc2xhdGUteS0xIGhvdmVyOnNoYWRvdy14bCAke3BsYW4ucG9wdWxhclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLWJsdWUtNDAwIGJnLWJsdWUtNDAwLzEwIHNoYWRvdy1sZyBzaGFkb3ctYmx1ZS01MDAvMjBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYm9yZGVyLXppbmMtODAwIGJnLXppbmMtOTUwLzUwIGhvdmVyOmJvcmRlci1ibHVlLTQwMC80MCBob3ZlcjpzaGFkb3ctYmx1ZS01MDAvMTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtYi0yIHRleHQtc20gdGV4dC16aW5jLTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwbGFuLnRpZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibWItMyB0ZXh0LTN4bCBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FubnVhbEJpbGxpbmcgPyBwbGFuLmFubnVhbCA6IHBsYW4ubW9udGhseX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BsYW4ubW9udGhseSAhPT0gXCJTb2IgY29uc3VsdGFcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC16aW5jLTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgL23DqnNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXppbmMtMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BsYW4uZGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cIm1iLTYgZmxleC0xIHNwYWNlLXktMiB0ZXh0LXNtIHRleHQtemluYy0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGxhbi5mZWF0dXJlcy5tYXAoKGZlYXR1cmUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2ZlYXR1cmV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYUNoZWNrQ2lyY2xlIGNsYXNzTmFtZT1cIm10LTAuNSB0ZXh0LWJsdWUtMzAwXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntmZWF0dXJlfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaHJlZj17Y29udGFjdEhyZWZ9IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LWF1dG8gYmxvY2sgdy1mdWxsIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci16aW5jLTYwMCBweC00IHB5LTIgdGV4dC1jZW50ZXIgZm9udC1tZWRpdW0gdHJhbnNpdGlvbiBob3Zlcjpib3JkZXItYmx1ZS00MDAgaG92ZXI6dGV4dC1ibHVlLTMwMCBmb2N1cy12aXNpYmxlOm91dGxpbmUtbm9uZSBmb2N1cy12aXNpYmxlOnJpbmctMiBmb2N1cy12aXNpYmxlOnJpbmctYmx1ZS00MDAgZm9jdXMtdmlzaWJsZTpyaW5nLW9mZnNldC0yIGZvY3VzLXZpc2libGU6cmluZy1vZmZzZXQtemluYy05NTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDb21lY2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9hcnRpY2xlPlxyXG4gICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgKTtcclxufSJdfQ==