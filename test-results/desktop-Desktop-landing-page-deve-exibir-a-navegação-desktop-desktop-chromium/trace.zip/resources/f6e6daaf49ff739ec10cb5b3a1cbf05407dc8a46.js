import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/BackToTopButton.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { FaArrowRight } from "/node_modules/.vite/deps/react-icons_fa.js?v=12888fd9";
var _jsxFileName = "C:/Users/uelin/Desktop/AI Company Landing/src/components/common/BackToTopButton.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12888fd9";
export default function BackToTopButton({ show }) {
	const handleScrollToTop = () => {
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	};
	const baseClasses = "fixed bottom-6 right-6 z-50 flex h-11 w-11 items-center justify-center rounded-xl border border-blue-400/40 bg-zinc-900/90 text-blue-300 shadow-lg shadow-blue-500/20 backdrop-blur transition-[opacity, transform] duration-300";
	const visibleClasses = show ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-4 opacity-0";
	return /* @__PURE__ */ _jsxDEV("button", {
		type: "button",
		"aria-label": "Voltar ao topo",
		onClick: handleScrollToTop,
		className: `${baseClasses} ${visibleClasses}
                cursor-pointer
                hover:-translate-y-1
                hover:border-blue-300/60
                hover:bg-zinc-800
                hover:text-white
                active:scale-95
                focus-visible:outline-none
                focus-visible:ring-2
                focus-visible:ring-blue-400
                focus-visible:ring-offset-2
                focus-visible:ring-offset-zinc-950
            `,
		children: /* @__PURE__ */ _jsxDEV(FaArrowRight, {
			className: "-rotate-90 transition-transform duration-300",
			"aria-hidden": "true"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 37,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 19,
		columnNumber: 9
	}, this);
}
_c = BackToTopButton;
var _c;
$RefreshReg$(_c, "BackToTopButton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/common/BackToTopButton.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/uelin/Desktop/AI Company Landing/src/components/common/BackToTopButton.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/uelin/Desktop/AI Company Landing/src/components/common/BackToTopButton.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/uelin/Desktop/AI Company Landing/src/components/common/BackToTopButton.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxvQkFBb0I7OztBQUU3QixlQUFlLFNBQVMsZ0JBQWdCLEVBQUUsUUFBUTtDQUM5QyxNQUFNLDBCQUEwQjtFQUM1QixPQUFPLFNBQVM7R0FDWixLQUFLO0dBQ0wsVUFBVTtFQUNkLENBQUM7Q0FDTDtDQUVBLE1BQU0sY0FDRjtDQUVKLE1BQU0saUJBQWlCLE9BQ2pCLDhCQUNBO0NBRU4sT0FDSSx3QkFBQyxVQUFEO0VBQ0ksTUFBSztFQUNMLGNBQVc7RUFDWCxTQUFTO0VBQ1QsV0FBVyxHQUFHLFlBQVksR0FBRyxlQUFlOzs7Ozs7Ozs7Ozs7O1lBYzVDLHdCQUFDLGNBQUQ7R0FDSSxXQUFVO0dBQ1YsZUFBWTtFQUNmOzs7OztDQUNHOzs7OztBQUVoQiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJCYWNrVG9Ub3BCdXR0b24uanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZhQXJyb3dSaWdodCB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQmFja1RvVG9wQnV0dG9uKHsgc2hvdyB9KSB7XHJcbiAgICBjb25zdCBoYW5kbGVTY3JvbGxUb1RvcCA9ICgpID0+IHtcclxuICAgICAgICB3aW5kb3cuc2Nyb2xsVG8oe1xyXG4gICAgICAgICAgICB0b3A6IDAsXHJcbiAgICAgICAgICAgIGJlaGF2aW9yOiBcInNtb290aFwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBiYXNlQ2xhc3NlcyA9XHJcbiAgICAgICAgXCJmaXhlZCBib3R0b20tNiByaWdodC02IHotNTAgZmxleCBoLTExIHctMTEgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ibHVlLTQwMC80MCBiZy16aW5jLTkwMC85MCB0ZXh0LWJsdWUtMzAwIHNoYWRvdy1sZyBzaGFkb3ctYmx1ZS01MDAvMjAgYmFja2Ryb3AtYmx1ciB0cmFuc2l0aW9uLVtvcGFjaXR5LCB0cmFuc2Zvcm1dIGR1cmF0aW9uLTMwMFwiO1xyXG5cclxuICAgIGNvbnN0IHZpc2libGVDbGFzc2VzID0gc2hvd1xyXG4gICAgICAgID8gXCJ0cmFuc2xhdGUteS0wIG9wYWNpdHktMTAwXCJcclxuICAgICAgICA6IFwicG9pbnRlci1ldmVudHMtbm9uZSB0cmFuc2xhdGUteS00IG9wYWNpdHktMFwiO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlZvbHRhciBhbyB0b3BvXCJcclxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU2Nyb2xsVG9Ub3B9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7YmFzZUNsYXNzZXN9ICR7dmlzaWJsZUNsYXNzZXN9XHJcbiAgICAgICAgICAgICAgICBjdXJzb3ItcG9pbnRlclxyXG4gICAgICAgICAgICAgICAgaG92ZXI6LXRyYW5zbGF0ZS15LTFcclxuICAgICAgICAgICAgICAgIGhvdmVyOmJvcmRlci1ibHVlLTMwMC82MFxyXG4gICAgICAgICAgICAgICAgaG92ZXI6YmctemluYy04MDBcclxuICAgICAgICAgICAgICAgIGhvdmVyOnRleHQtd2hpdGVcclxuICAgICAgICAgICAgICAgIGFjdGl2ZTpzY2FsZS05NVxyXG4gICAgICAgICAgICAgICAgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW5vbmVcclxuICAgICAgICAgICAgICAgIGZvY3VzLXZpc2libGU6cmluZy0yXHJcbiAgICAgICAgICAgICAgICBmb2N1cy12aXNpYmxlOnJpbmctYmx1ZS00MDBcclxuICAgICAgICAgICAgICAgIGZvY3VzLXZpc2libGU6cmluZy1vZmZzZXQtMlxyXG4gICAgICAgICAgICAgICAgZm9jdXMtdmlzaWJsZTpyaW5nLW9mZnNldC16aW5jLTk1MFxyXG4gICAgICAgICAgICBgfVxyXG4gICAgICAgID5cclxuICAgICAgICAgICAgPEZhQXJyb3dSaWdodFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiLXJvdGF0ZS05MCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDBcIlxyXG4gICAgICAgICAgICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICk7XHJcbn0iXX0=