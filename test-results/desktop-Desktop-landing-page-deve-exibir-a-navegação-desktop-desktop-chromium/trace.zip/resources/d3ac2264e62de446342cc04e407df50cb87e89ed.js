import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sections/AboutSection.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { team } from "/src/data/landingData.js";
var _jsxFileName = "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/AboutSection.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12888fd9";
export default function AboutSection() {
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "about",
		"data-reveal": true,
		className: "scroll-mt-28 reveal-up grid gap-8 rounded-2xl border border-zinc-800 bg-linear-to-r from-zinc-900 to-zinc-900/40 p-8 md:grid-cols-2",
		children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
			className: "mb-4 text-2xl font-semibold md:text-3xl",
			children: "Construído por especialistas em IA para equipes de produção"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 11,
			columnNumber: 17
		}, this), /* @__PURE__ */ _jsxDEV("p", {
			className: "text-zinc-300",
			children: "Somos uma equipe multifuncional formado por pesquisadores de IA, engenheiros e líderes de produto focados em fornecer inteligência prática na velocidade de uma startup."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 15,
			columnNumber: 17
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 10,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "space-y-4",
			children: team.map((member) => /* @__PURE__ */ _jsxDEV("div", {
				className: "rounded-lg border border-zinc-700 bg-zinc-950/50 px-4 py-3 transition-all duration-300 hover:-translate-y-0.5 hover:border-blue-400/40",
				children: [/* @__PURE__ */ _jsxDEV("p", {
					className: "font-medium",
					children: member.name
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 25
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-sm text-zinc-400",
					children: member.role
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 27,
					columnNumber: 25
				}, this)]
			}, member.name, true, {
				fileName: _jsxFileName,
				lineNumber: 22,
				columnNumber: 21
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 13
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 5,
		columnNumber: 9
	}, this);
}
_c = AboutSection;
var _c;
$RefreshReg$(_c, "AboutSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/sections/AboutSection.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/AboutSection.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/AboutSection.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/AboutSection.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZOzs7QUFFckIsZUFBZSxTQUFTLGVBQWU7Q0FDbkMsT0FDSSx3QkFBQyxXQUFEO0VBQ0ksSUFBRztFQUNIO0VBQ0EsV0FBVTtZQUhkLENBS0ksd0JBQUMsT0FBRCxhQUNJLHdCQUFDLE1BQUQ7R0FBSSxXQUFVO2FBQTBDO0VBRXBEOzs7O1lBRUosd0JBQUMsS0FBRDtHQUFHLFdBQVU7YUFBZ0I7RUFFMUI7Ozs7VUFDRjs7OztZQUVMLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ1YsS0FBSyxLQUFLLFdBQ1Asd0JBQUMsT0FBRDtJQUVJLFdBQVU7Y0FGZCxDQUlJLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWUsT0FBTztJQUFROzs7O2NBQzNDLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQXlCLE9BQU87SUFBUTs7OztZQUNwRDtNQUxJLE9BQU87Ozs7VUFLWCxDQUNSO0VBQ0E7Ozs7VUFDQTs7Ozs7O0FBRWpCIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFib3V0U2VjdGlvbi5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdGVhbSB9IGZyb20gXCIuLi8uLi9kYXRhL2xhbmRpbmdEYXRhXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBYm91dFNlY3Rpb24oKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxzZWN0aW9uXHJcbiAgICAgICAgICAgIGlkPVwiYWJvdXRcIlxyXG4gICAgICAgICAgICBkYXRhLXJldmVhbFxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJzY3JvbGwtbXQtMjggcmV2ZWFsLXVwIGdyaWQgZ2FwLTggcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci16aW5jLTgwMCBiZy1saW5lYXItdG8tciBmcm9tLXppbmMtOTAwIHRvLXppbmMtOTAwLzQwIHAtOCBtZDpncmlkLWNvbHMtMlwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtZDp0ZXh0LTN4bFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIENvbnN0cnXDrWRvIHBvciBlc3BlY2lhbGlzdGFzIGVtIElBIHBhcmEgZXF1aXBlcyBkZSBwcm9kdcOnw6NvXHJcbiAgICAgICAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtemluYy0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBTb21vcyB1bWEgZXF1aXBlIG11bHRpZnVuY2lvbmFsIGZvcm1hZG8gcG9yIHBlc3F1aXNhZG9yZXMgZGUgSUEsIGVuZ2VuaGVpcm9zIGUgbMOtZGVyZXMgZGUgcHJvZHV0byBmb2NhZG9zIGVtIGZvcm5lY2VyIGludGVsaWfDqm5jaWEgcHLDoXRpY2EgbmEgdmVsb2NpZGFkZSBkZSB1bWEgc3RhcnR1cC5cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgICAge3RlYW0ubWFwKChtZW1iZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17bWVtYmVyLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci16aW5jLTcwMCBiZy16aW5jLTk1MC81MCBweC00IHB5LTMgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGhvdmVyOi10cmFuc2xhdGUteS0wLjUgaG92ZXI6Ym9yZGVyLWJsdWUtNDAwLzQwXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+e21lbWJlci5uYW1lfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXppbmMtNDAwXCI+e21lbWJlci5yb2xlfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICApO1xyXG59Il19