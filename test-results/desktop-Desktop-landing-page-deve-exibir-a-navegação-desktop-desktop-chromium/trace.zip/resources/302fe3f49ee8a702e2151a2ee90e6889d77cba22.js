import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sections/HeroSection.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { stats } from "/src/data/landingData.js";
var _jsxFileName = "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/HeroSection.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12888fd9";
export default function HeroSection() {
	return /* @__PURE__ */ _jsxDEV("section", {
		"data-reveal": true,
		className: "reveal-up grid gap-12 lg:grid-cols-2 lg:items-center",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "text-center lg:text-start",
			children: [
				/* @__PURE__ */ _jsxDEV("p", {
					className: "mb-4 inline-flex rounded-full border border-blue-400/30 bg-blue-400/10 px-4 py-1 text-sm text-blue-300 animate-pulse",
					children: "Infraestrutura de IA Moderna para Equipes que Querem Crescer"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 10,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("h1", {
					className: "mb-6 bg-linear-to-r from-white to-blue-200 bg-clip-text text-4xl font-bold leading-tight text-transparent sm:text-5xl",
					children: "Use uma IA que entrega valor desde o primeiro dia."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 14,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col items-center lg:items-start",
					children: /* @__PURE__ */ _jsxDEV("p", {
						className: "mb-8 max-w-xl text-lg text-zinc-300",
						children: "Ajudamos startups e empresas a lançar seus produtos com confiança, rapidez e segurança. Gerando impacto real nos seus negócios."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 19,
						columnNumber: 21
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 18,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-wrap justify-center gap-4 lg:justify-start",
					children: [/* @__PURE__ */ _jsxDEV("a", {
						href: "mailto:ola@exemplo.com?subject=Teste%20Gr%C3%A1tis%20Synapse%20IA",
						className: "rounded-lg bg-blue-500 px-6 py-3 font-semibold text-white shadow-blue-500/20 transition hover:-translate-y-0.5 hover:bg-blue-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 focus-visible:ring-offset-2 focus-visible:ring-offset-black",
						children: "Comece o Teste Grátis"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("a", {
						href: "#showcase",
						className: "rounded-lg border border-zinc-600 px-6 py-3 font-semibold transition hover:border-blue-400 hover:text-blue-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 focus-visible:ring-offset-2 focus-visible:ring-offset-black",
						children: "Ver Plataforma"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 32,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 24,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mt-8 grid grid-cols-2 gap-2 md:grid-cols-4 lg:gap-12",
					children: stats.map((item) => /* @__PURE__ */ _jsxDEV("div", {
						className: "flex min-w-0 flex-col items-center justify-center rounded-xl border border-zinc-800 bg-zinc-900/40 p-6 transition-all duration-300 hover:-translate-y-1 hover:border-blue-400/40",
						children: [/* @__PURE__ */ _jsxDEV("p", {
							className: "text-3xl font-bold tracking-tight text-blue-300",
							children: item.value
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "mt-3 max-w-[14ch] text-center text-sm font-semibold uppercase leading-relaxed tracking-wide text-zinc-400",
							children: item.label
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 50,
							columnNumber: 29
						}, this)]
					}, item.label, true, {
						fileName: _jsxFileName,
						lineNumber: 42,
						columnNumber: 25
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 40,
					columnNumber: 17
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 9,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "relative rounded-2xl border border-zinc-800 bg-zinc-900/60 p-6 shadow-2xl shadow-blue-500/10",
			children: [
				/* @__PURE__ */ _jsxDEV("div", { className: "absolute -inset-0.5 -z-10 rounded-2xl bg-linear-to-r from-blue-500/15 to-white/10 blur-md" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 59,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mb-6 flex flex-col items-center gap-2 lg:flex-row lg:justify-between",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-lg font-semibold",
						children: "Operações com IA"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "w-45 rounded-full bg-emerald-400/15 p-2 text-center text-sm font-semibold  text-emerald-300",
						children: "+127% de Produtividade"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-4",
					children: [
						"Suporte ao Cliente",
						"Apoio a Vendas",
						"Processamento de Dados"
					].map((item) => /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between rounded-xl border border-zinc-800 bg-zinc-950/70 px-4 py-3 transition-all duration-300 hover:border-blue-400/40 hover:bg-zinc-900",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-zinc-200",
							children: item
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-sm text-blue-300",
							children: "IA Ativa"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 85,
							columnNumber: 29
						}, this)]
					}, item, true, {
						fileName: _jsxFileName,
						lineNumber: 77,
						columnNumber: 25
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 17
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 58,
			columnNumber: 13
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 5,
		columnNumber: 9
	}, this);
}
_c = HeroSection;
var _c;
$RefreshReg$(_c, "HeroSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/sections/HeroSection.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/HeroSection.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/HeroSection.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/HeroSection.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhOzs7QUFFdEIsZUFBZSxTQUFTLGNBQWM7Q0FDbEMsT0FDSSx3QkFBQyxXQUFEO0VBQ0k7RUFDQSxXQUFVO1lBRmQsQ0FJSSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0ksd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBdUg7SUFFakk7Ozs7O0lBRUgsd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBd0g7SUFFbEk7Ozs7O0lBRUosd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWCx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBc0M7S0FFaEQ7Ozs7O0lBQ0Y7Ozs7O0lBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNJLHdCQUFDLEtBQUQ7TUFDSSxNQUFLO01BQ0wsV0FBVTtnQkFDYjtLQUVFOzs7O2VBRUgsd0JBQUMsS0FBRDtNQUNJLE1BQUs7TUFDTCxXQUFVO2dCQUNiO0tBRUU7Ozs7YUFDRjs7Ozs7O0lBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDVixNQUFNLEtBQUssU0FDUix3QkFBQyxPQUFEO01BRUksV0FBVTtnQkFGZCxDQUlJLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUNSLEtBQUs7TUFDUDs7OztnQkFFSCx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFDUixLQUFLO01BQ1A7Ozs7Y0FDRjtRQVZJLEtBQUs7Ozs7WUFVVCxDQUNSO0lBQ0E7Ozs7O0dBQ0o7Ozs7O1lBRUwsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNJLHdCQUFDLE9BQUQsRUFBSyxXQUFVLDRGQUE2Rjs7Ozs7SUFFNUcsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNJLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUF3QjtLQUVsQzs7OztlQUVKLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUE4RjtLQUV4Rzs7OzthQUNMOzs7Ozs7SUFFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNWO01BQ0c7TUFDQTtNQUNBO0tBQ0osQ0FBQyxDQUFDLEtBQUssU0FDSCx3QkFBQyxPQUFEO01BRUksV0FBVTtnQkFGZCxDQUlJLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUNYO01BQ0M7Ozs7Z0JBRU4sd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQXdCO01BRWxDOzs7O2NBQ0w7UUFWSTs7OztZQVVKLENBQ1I7SUFDQTs7Ozs7R0FDSjs7Ozs7VUFDQTs7Ozs7O0FBRWpCIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkhlcm9TZWN0aW9uLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBzdGF0cyB9IGZyb20gXCIuLi8uLi9kYXRhL2xhbmRpbmdEYXRhXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBIZXJvU2VjdGlvbigpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPHNlY3Rpb25cclxuICAgICAgICAgICAgZGF0YS1yZXZlYWxcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicmV2ZWFsLXVwIGdyaWQgZ2FwLTEyIGxnOmdyaWQtY29scy0yIGxnOml0ZW1zLWNlbnRlclwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIGxnOnRleHQtc3RhcnRcIj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm1iLTQgaW5saW5lLWZsZXggcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItYmx1ZS00MDAvMzAgYmctYmx1ZS00MDAvMTAgcHgtNCBweS0xIHRleHQtc20gdGV4dC1ibHVlLTMwMCBhbmltYXRlLXB1bHNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgSW5mcmFlc3RydXR1cmEgZGUgSUEgTW9kZXJuYSBwYXJhIEVxdWlwZXMgcXVlIFF1ZXJlbSBDcmVzY2VyXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cIm1iLTYgYmctbGluZWFyLXRvLXIgZnJvbS13aGl0ZSB0by1ibHVlLTIwMCBiZy1jbGlwLXRleHQgdGV4dC00eGwgZm9udC1ib2xkIGxlYWRpbmctdGlnaHQgdGV4dC10cmFuc3BhcmVudCBzbTp0ZXh0LTV4bFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFVzZSB1bWEgSUEgcXVlIGVudHJlZ2EgdmFsb3IgZGVzZGUgbyBwcmltZWlybyBkaWEuXHJcbiAgICAgICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGxnOml0ZW1zLXN0YXJ0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibWItOCBtYXgtdy14bCB0ZXh0LWxnIHRleHQtemluYy0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQWp1ZGFtb3Mgc3RhcnR1cHMgZSBlbXByZXNhcyBhIGxhbsOnYXIgc2V1cyBwcm9kdXRvcyBjb20gY29uZmlhbsOnYSwgcmFwaWRleiBlIHNlZ3VyYW7Dp2EuIEdlcmFuZG8gaW1wYWN0byByZWFsIG5vcyBzZXVzIG5lZ8OzY2lvcy5cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGp1c3RpZnktY2VudGVyIGdhcC00IGxnOmp1c3RpZnktc3RhcnRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBocmVmPVwibWFpbHRvOm9sYUBleGVtcGxvLmNvbT9zdWJqZWN0PVRlc3RlJTIwR3IlQzMlQTF0aXMlMjBTeW5hcHNlJTIwSUFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJnLWJsdWUtNTAwIHB4LTYgcHktMyBmb250LXNlbWlib2xkIHRleHQtd2hpdGUgc2hhZG93LWJsdWUtNTAwLzIwIHRyYW5zaXRpb24gaG92ZXI6LXRyYW5zbGF0ZS15LTAuNSBob3ZlcjpiZy1ibHVlLTQwMCBmb2N1cy12aXNpYmxlOm91dGxpbmUtbm9uZSBmb2N1cy12aXNpYmxlOnJpbmctMiBmb2N1cy12aXNpYmxlOnJpbmctYmx1ZS00MDAgZm9jdXMtdmlzaWJsZTpyaW5nLW9mZnNldC0yIGZvY3VzLXZpc2libGU6cmluZy1vZmZzZXQtYmxhY2tcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQ29tZWNlIG8gVGVzdGUgR3LDoXRpc1xyXG4gICAgICAgICAgICAgICAgICAgIDwvYT5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgICAgICAgaHJlZj1cIiNzaG93Y2FzZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci16aW5jLTYwMCBweC02IHB5LTMgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uIGhvdmVyOmJvcmRlci1ibHVlLTQwMCBob3Zlcjp0ZXh0LWJsdWUtMzAwIGZvY3VzLXZpc2libGU6b3V0bGluZS1ub25lIGZvY3VzLXZpc2libGU6cmluZy0yIGZvY3VzLXZpc2libGU6cmluZy1ibHVlLTQwMCBmb2N1cy12aXNpYmxlOnJpbmctb2Zmc2V0LTIgZm9jdXMtdmlzaWJsZTpyaW5nLW9mZnNldC1ibGFja1wiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBWZXIgUGxhdGFmb3JtYVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtOCBncmlkIGdyaWQtY29scy0yIGdhcC0yIG1kOmdyaWQtY29scy00IGxnOmdhcC0xMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtzdGF0cy5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpdGVtLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBtaW4tdy0wIGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItemluYy04MDAgYmctemluYy05MDAvNDAgcC02IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBob3ZlcjotdHJhbnNsYXRlLXktMSBob3Zlcjpib3JkZXItYmx1ZS00MDAvNDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibHVlLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnZhbHVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgbWF4LXctWzE0Y2hdIHRleHQtY2VudGVyIHRleHQtc20gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgbGVhZGluZy1yZWxheGVkIHRyYWNraW5nLXdpZGUgdGV4dC16aW5jLTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci16aW5jLTgwMCBiZy16aW5jLTkwMC82MCBwLTYgc2hhZG93LTJ4bCBzaGFkb3ctYmx1ZS01MDAvMTBcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLWluc2V0LTAuNSAtei0xMCByb3VuZGVkLTJ4bCBiZy1saW5lYXItdG8tciBmcm9tLWJsdWUtNTAwLzE1IHRvLXdoaXRlLzEwIGJsdXItbWRcIiAvPlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNiBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBnYXAtMiBsZzpmbGV4LXJvdyBsZzpqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIE9wZXJhw6fDtWVzIGNvbSBJQVxyXG4gICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctNDUgcm91bmRlZC1mdWxsIGJnLWVtZXJhbGQtNDAwLzE1IHAtMiB0ZXh0LWNlbnRlciB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgIHRleHQtZW1lcmFsZC0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKzEyNyUgZGUgUHJvZHV0aXZpZGFkZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAge1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgXCJTdXBvcnRlIGFvIENsaWVudGVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgXCJBcG9pbyBhIFZlbmRhc1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBcIlByb2Nlc3NhbWVudG8gZGUgRGFkb3NcIixcclxuICAgICAgICAgICAgICAgICAgICBdLm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXppbmMtODAwIGJnLXppbmMtOTUwLzcwIHB4LTQgcHktMyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgaG92ZXI6Ym9yZGVyLWJsdWUtNDAwLzQwIGhvdmVyOmJnLXppbmMtOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC16aW5jLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ibHVlLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIElBIEF0aXZhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgICk7XHJcbn0iXX0=