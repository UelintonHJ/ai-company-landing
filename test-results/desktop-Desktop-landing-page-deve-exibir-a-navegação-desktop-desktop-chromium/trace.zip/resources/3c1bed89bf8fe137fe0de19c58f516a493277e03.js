import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sections/LandingSections.jsx");const _jsxDEV = __vite__cjsImport12_react_jsxDevRuntime["jsxDEV"];import HeroSection from "/src/components/sections/HeroSection.jsx";
import ServicesSection from "/src/components/sections/ServicesSection.jsx";
import ShowcaseSection from "/src/components/sections/ShowcaseSection.jsx";
import PartnersSection from "/src/components/sections/PartnersSection.jsx";
import WorkflowSection from "/src/components/sections/WorkflowSection.jsx";
import FeaturesSection from "/src/components/sections/FeaturesSection.jsx";
import TestimonialsSection from "/src/components/sections/TestimonialsSection.jsx";
import IntegrationsSection from "/src/components/sections/IntegrationsSection.jsx";
import PricingSection from "/src/components/sections/PricingSection.jsx";
import AboutSection from "/src/components/sections/AboutSection.jsx";
import FAQSection from "/src/components/sections/FAQSection.jsx";
import CTASection from "/src/components/sections/CTASection.jsx";
var _jsxFileName = "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/LandingSections.jsx";
import __vite__cjsImport12_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12888fd9";
export default function LandingSections() {
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "space-y-24",
		children: [
			/* @__PURE__ */ _jsxDEV(HeroSection, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 17,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(ServicesSection, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(ShowcaseSection, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(PartnersSection, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(WorkflowSection, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(FeaturesSection, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(TestimonialsSection, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(IntegrationsSection, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(PricingSection, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(AboutSection, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(FAQSection, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 37,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(CTASection, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 39,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 16,
		columnNumber: 9
	}, this);
}
_c = LandingSections;
var _c;
$RefreshReg$(_c, "LandingSections");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/sections/LandingSections.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/LandingSections.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/LandingSections.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/LandingSections.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxpQkFBaUI7QUFDeEIsT0FBTyxxQkFBcUI7QUFDNUIsT0FBTyxxQkFBcUI7QUFDNUIsT0FBTyxxQkFBcUI7QUFDNUIsT0FBTyxxQkFBcUI7QUFDNUIsT0FBTyxxQkFBcUI7QUFDNUIsT0FBTyx5QkFBeUI7QUFDaEMsT0FBTyx5QkFBeUI7QUFDaEMsT0FBTyxvQkFBb0I7QUFDM0IsT0FBTyxrQkFBa0I7QUFDekIsT0FBTyxnQkFBZ0I7QUFDdkIsT0FBTyxnQkFBZ0I7OztBQUV2QixlQUFlLFNBQVMsa0JBQWtCO0NBQ3RDLE9BQ0ksd0JBQUMsUUFBRDtFQUFNLFdBQVU7WUFBaEI7R0FDSSx3QkFBQyxhQUFELENBQWM7Ozs7O0dBRWQsd0JBQUMsaUJBQUQsQ0FBa0I7Ozs7O0dBRWxCLHdCQUFDLGlCQUFELENBQWtCOzs7OztHQUVsQix3QkFBQyxpQkFBRCxDQUFrQjs7Ozs7R0FFbEIsd0JBQUMsaUJBQUQsQ0FBa0I7Ozs7O0dBRWxCLHdCQUFDLGlCQUFELENBQWtCOzs7OztHQUVsQix3QkFBQyxxQkFBRCxDQUFzQjs7Ozs7R0FFdEIsd0JBQUMscUJBQUQsQ0FBc0I7Ozs7O0dBRXRCLHdCQUFDLGdCQUFELENBQWlCOzs7OztHQUVqQix3QkFBQyxjQUFELENBQWU7Ozs7O0dBRWYsd0JBQUMsWUFBRCxDQUFhOzs7OztHQUViLHdCQUFDLFlBQUQsQ0FBYTs7Ozs7RUFDWDs7Ozs7O0FBRWQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTGFuZGluZ1NlY3Rpb25zLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgSGVyb1NlY3Rpb24gZnJvbSAnLi9IZXJvU2VjdGlvbic7XHJcbmltcG9ydCBTZXJ2aWNlc1NlY3Rpb24gZnJvbSAnLi9TZXJ2aWNlc1NlY3Rpb24nO1xyXG5pbXBvcnQgU2hvd2Nhc2VTZWN0aW9uIGZyb20gJy4vU2hvd2Nhc2VTZWN0aW9uJztcclxuaW1wb3J0IFBhcnRuZXJzU2VjdGlvbiBmcm9tICcuL1BhcnRuZXJzU2VjdGlvbic7XHJcbmltcG9ydCBXb3JrZmxvd1NlY3Rpb24gZnJvbSAnLi9Xb3JrZmxvd1NlY3Rpb24nO1xyXG5pbXBvcnQgRmVhdHVyZXNTZWN0aW9uIGZyb20gJy4vRmVhdHVyZXNTZWN0aW9uJztcclxuaW1wb3J0IFRlc3RpbW9uaWFsc1NlY3Rpb24gZnJvbSAnLi9UZXN0aW1vbmlhbHNTZWN0aW9uJztcclxuaW1wb3J0IEludGVncmF0aW9uc1NlY3Rpb24gZnJvbSAnLi9JbnRlZ3JhdGlvbnNTZWN0aW9uJztcclxuaW1wb3J0IFByaWNpbmdTZWN0aW9uIGZyb20gJy4vUHJpY2luZ1NlY3Rpb24nO1xyXG5pbXBvcnQgQWJvdXRTZWN0aW9uIGZyb20gJy4vQWJvdXRTZWN0aW9uJztcclxuaW1wb3J0IEZBUVNlY3Rpb24gZnJvbSAnLi9GQVFTZWN0aW9uJztcclxuaW1wb3J0IENUQVNlY3Rpb24gZnJvbSAnLi9DVEFTZWN0aW9uJztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExhbmRpbmdTZWN0aW9ucygpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPG1haW4gY2xhc3NOYW1lPVwic3BhY2UteS0yNFwiPlxyXG4gICAgICAgICAgICA8SGVyb1NlY3Rpb24gLz5cclxuXHJcbiAgICAgICAgICAgIDxTZXJ2aWNlc1NlY3Rpb24gLz5cclxuXHJcbiAgICAgICAgICAgIDxTaG93Y2FzZVNlY3Rpb24gLz5cclxuXHJcbiAgICAgICAgICAgIDxQYXJ0bmVyc1NlY3Rpb24gLz5cclxuXHJcbiAgICAgICAgICAgIDxXb3JrZmxvd1NlY3Rpb24gLz5cclxuXHJcbiAgICAgICAgICAgIDxGZWF0dXJlc1NlY3Rpb24gLz5cclxuXHJcbiAgICAgICAgICAgIDxUZXN0aW1vbmlhbHNTZWN0aW9uIC8+XHJcblxyXG4gICAgICAgICAgICA8SW50ZWdyYXRpb25zU2VjdGlvbiAvPlxyXG5cclxuICAgICAgICAgICAgPFByaWNpbmdTZWN0aW9uIC8+XHJcblxyXG4gICAgICAgICAgICA8QWJvdXRTZWN0aW9uIC8+XHJcblxyXG4gICAgICAgICAgICA8RkFRU2VjdGlvbiAvPlxyXG5cclxuICAgICAgICAgICAgPENUQVNlY3Rpb24gLz5cclxuICAgICAgICA8L21haW4+XHJcbiAgICApO1xyXG59Il19