import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sections/PartnersSection.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { partners } from "/src/data/landingData.js";
var _jsxFileName = "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/PartnersSection.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12888fd9";
export default function PartnersSection() {
	return /* @__PURE__ */ _jsxDEV("section", {
		"data-reveal": true,
		className: "reveal-up",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "mb-6 flex flex-wrap items-center gap-3 text-xs uppercase tracking-widest text-zinc-400",
			children: [/* @__PURE__ */ _jsxDEV("span", { children: "Recomendado por" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 7,
				columnNumber: 17
			}, this), partners.map((brand) => /* @__PURE__ */ _jsxDEV("span", {
				className: "rounded-full border border-zinc-700 px-3 py-1 transition-all duration-300 hover:border-blue-400 hover:text-blue-300",
				children: brand
			}, brand, false, {
				fileName: _jsxFileName,
				lineNumber: 10,
				columnNumber: 21
			}, this))]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 6,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 5,
		columnNumber: 9
	}, this);
}
_c = PartnersSection;
var _c;
$RefreshReg$(_c, "PartnersSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/sections/PartnersSection.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/PartnersSection.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/PartnersSection.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/PartnersSection.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7OztBQUV6QixlQUFlLFNBQVMsa0JBQWtCO0NBQ3RDLE9BQ0ksd0JBQUMsV0FBRDtFQUFTO0VBQVksV0FBVTtZQUMzQix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0ksd0JBQUMsUUFBRCxZQUFNLGtCQUFxQjs7OzthQUUxQixTQUFTLEtBQUssVUFDWCx3QkFBQyxRQUFEO0lBRUksV0FBVTtjQUVUO0dBQ0MsR0FKRzs7OztVQUlILENBQ1QsQ0FDQTs7Ozs7O0NBQ0E7Ozs7O0FBRWpCIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlBhcnRuZXJzU2VjdGlvbi5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgcGFydG5lcnMgfSBmcm9tIFwiLi4vLi4vZGF0YS9sYW5kaW5nRGF0YVwiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUGFydG5lcnNTZWN0aW9uKCkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8c2VjdGlvbiBkYXRhLXJldmVhbCBjbGFzc05hbWU9XCJyZXZlYWwtdXBcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02IGZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMyB0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgdGV4dC16aW5jLTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+UmVjb21lbmRhZG8gcG9yPC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgICAgIHtwYXJ0bmVycy5tYXAoKGJyYW5kKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXticmFuZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItemluYy03MDAgcHgtMyBweS0xIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBob3Zlcjpib3JkZXItYmx1ZS00MDAgaG92ZXI6dGV4dC1ibHVlLTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7YnJhbmR9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgIClcclxufSJdfQ==