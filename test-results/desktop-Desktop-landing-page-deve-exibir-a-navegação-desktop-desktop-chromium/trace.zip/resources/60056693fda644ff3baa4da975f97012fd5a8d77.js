import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sections/CTASection.jsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/CTASection.jsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12888fd9";
export default function CTASection() {
	return /* @__PURE__ */ _jsxDEV("section", {
		"data-reveal": true,
		className: "reveal-up rounded-2xl border border-blue-400/30 bg-blue-500/10 p-8 text-center",
		children: [
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "mb-4 text-2xl font-semibold md:text-3xl",
				children: "Pronto para crescer?"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 7,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "mx-auto mb-6 max-w-2xl text-zinc-200",
				children: "Lance seu primeiro workflow em dias, não meses. Junte-se às grandes empresas que usam Synapse para automatizar, prever e crescer mais rápido."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("a", {
				href: "mailto:ola@exemplo.com?subject=Contato%20-%20Synapse%20IA",
				className: "inline-flex rounded-lg bg-blue-500 px-7 py-3 font-semibold text-white shadow-lg shadow-blue-500/15 transition-all duration-300 hover:-translate-y-0.5 hover:bg-blue-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 focus-visible:ring-offset-2 focus-visible:ring-offset-zinc-950",
				children: "Fale conosco"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 16,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 3,
		columnNumber: 9
	}, this);
}
_c = CTASection;
var _c;
$RefreshReg$(_c, "CTASection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/sections/CTASection.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/CTASection.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/CTASection.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/CTASection.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFBQSxlQUFlLFNBQVMsYUFBYTtDQUNqQyxPQUNJLHdCQUFDLFdBQUQ7RUFDSTtFQUNBLFdBQVU7WUFGZDtHQUlJLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQTBDO0dBRXBEOzs7OztHQUVKLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQXVDO0dBR2pEOzs7OztHQUVILHdCQUFDLEtBQUQ7SUFDSSxNQUFLO0lBQ0wsV0FBVTtjQUNiO0dBRUU7Ozs7O0VBQ0U7Ozs7OztBQUVqQiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJDVEFTZWN0aW9uLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDVEFTZWN0aW9uKCkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8c2VjdGlvblxyXG4gICAgICAgICAgICBkYXRhLXJldmVhbFxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJyZXZlYWwtdXAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ibHVlLTQwMC8zMCBiZy1ibHVlLTUwMC8xMCBwLTggdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtZDp0ZXh0LTN4bFwiPlxyXG4gICAgICAgICAgICAgICAgUHJvbnRvIHBhcmEgY3Jlc2Nlcj9cclxuICAgICAgICAgICAgPC9oMj5cclxuXHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm14LWF1dG8gbWItNiBtYXgtdy0yeGwgdGV4dC16aW5jLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgTGFuY2Ugc2V1IHByaW1laXJvIHdvcmtmbG93IGVtIGRpYXMsIG7Do28gbWVzZXMuXHJcbiAgICAgICAgICAgICAgICBKdW50ZS1zZSDDoHMgZ3JhbmRlcyBlbXByZXNhcyBxdWUgdXNhbSBTeW5hcHNlIHBhcmEgYXV0b21hdGl6YXIsIHByZXZlciBlIGNyZXNjZXIgbWFpcyByw6FwaWRvLlxyXG4gICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICA8YSBcclxuICAgICAgICAgICAgICAgIGhyZWY9XCJtYWlsdG86b2xhQGV4ZW1wbG8uY29tP3N1YmplY3Q9Q29udGF0byUyMC0lMjBTeW5hcHNlJTIwSUFcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcm91bmRlZC1sZyBiZy1ibHVlLTUwMCBweC03IHB5LTMgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlIHNoYWRvdy1sZyBzaGFkb3ctYmx1ZS01MDAvMTUgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGhvdmVyOi10cmFuc2xhdGUteS0wLjUgaG92ZXI6YmctYmx1ZS00MDAgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW5vbmUgZm9jdXMtdmlzaWJsZTpyaW5nLTIgZm9jdXMtdmlzaWJsZTpyaW5nLWJsdWUtNDAwIGZvY3VzLXZpc2libGU6cmluZy1vZmZzZXQtMiBmb2N1cy12aXNpYmxlOnJpbmctb2Zmc2V0LXppbmMtOTUwXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgRmFsZSBjb25vc2NvXHJcbiAgICAgICAgICAgIDwvYT5cclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICApXHJcbn0iXX0=