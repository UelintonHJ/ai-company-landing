import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sections/FeaturesSection.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { features } from "/src/data/landingData.js";
var _jsxFileName = "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/FeaturesSection.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12888fd9";
export default function FeaturesSection() {
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "features",
		"data-reveal": true,
		className: "scroll-mt-28 reveal-up",
		children: [/* @__PURE__ */ _jsxDEV("h2", {
			className: "mb-8 text-2xl font-semibold md:text-3xl",
			children: "Os Motivos por Sermos A Escolha das Empresas"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 6,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "grid gap-6 md:grid-cols-3",
			children: features.map((feature) => /* @__PURE__ */ _jsxDEV("article", {
				className: "rounded-xl border border-zinc-800 bg-zinc-900/40 p-6 transition-all duration-300 hover:-translate-y-1.5 hover:border-blue-400 hover:shadow-lg hover:shadow-blue-500/10",
				children: [
					/* @__PURE__ */ _jsxDEV(feature.icon, {
						className: "mb-3 text-xl text-blue-300",
						"aria-hidden": "true"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 16,
						columnNumber: 25
					}, this),
					/* @__PURE__ */ _jsxDEV("h3", {
						className: "mb-3 text-xl font-semibold",
						children: feature.title
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 18,
						columnNumber: 25
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-zinc-300",
						children: feature.description
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 22,
						columnNumber: 25
					}, this)
				]
			}, feature.title, true, {
				fileName: _jsxFileName,
				lineNumber: 12,
				columnNumber: 21
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 10,
			columnNumber: 13
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 5,
		columnNumber: 9
	}, this);
}
_c = FeaturesSection;
var _c;
$RefreshReg$(_c, "FeaturesSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/sections/FeaturesSection.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/FeaturesSection.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/FeaturesSection.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/FeaturesSection.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7OztBQUV6QixlQUFlLFNBQVMsa0JBQWtCO0NBQ3RDLE9BQ0ksd0JBQUMsV0FBRDtFQUFTLElBQUc7RUFBVztFQUFZLFdBQVU7WUFBN0MsQ0FDSSx3QkFBQyxNQUFEO0dBQUksV0FBVTthQUEwQztFQUVwRDs7OztZQUVKLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ1YsU0FBUyxLQUFLLFlBQ1gsd0JBQUMsV0FBRDtJQUVJLFdBQVU7Y0FGZDtLQUlJLHdCQUFDLFFBQVEsTUFBVDtNQUFjLFdBQVU7TUFBNkIsZUFBWTtLQUFROzs7OztLQUV6RSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFDVCxRQUFRO0tBQ1Q7Ozs7O0tBRUosd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQ1IsUUFBUTtLQUNWOzs7OztJQUNFO01BWkEsUUFBUTs7OztVQVlSLENBQ1o7RUFDQTs7OztVQUNBOzs7Ozs7QUFFakIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRmVhdHVyZXNTZWN0aW9uLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBmZWF0dXJlcyB9IGZyb20gXCIuLi8uLi9kYXRhL2xhbmRpbmdEYXRhXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBGZWF0dXJlc1NlY3Rpb24oKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxzZWN0aW9uIGlkPVwiZmVhdHVyZXNcIiBkYXRhLXJldmVhbCBjbGFzc05hbWU9XCJzY3JvbGwtbXQtMjggcmV2ZWFsLXVwXCI+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJtYi04IHRleHQtMnhsIGZvbnQtc2VtaWJvbGQgbWQ6dGV4dC0zeGxcIj5cclxuICAgICAgICAgICAgICAgIE9zIE1vdGl2b3MgcG9yIFNlcm1vcyBBIEVzY29saGEgZGFzIEVtcHJlc2FzXHJcbiAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTYgbWQ6Z3JpZC1jb2xzLTNcIj5cclxuICAgICAgICAgICAgICAgIHtmZWF0dXJlcy5tYXAoKGZlYXR1cmUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8YXJ0aWNsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2ZlYXR1cmUudGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci16aW5jLTgwMCBiZy16aW5jLTkwMC80MCBwLTYgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGhvdmVyOi10cmFuc2xhdGUteS0xLjUgaG92ZXI6Ym9yZGVyLWJsdWUtNDAwIGhvdmVyOnNoYWRvdy1sZyBob3ZlcjpzaGFkb3ctYmx1ZS01MDAvMTBcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGZlYXR1cmUuaWNvbiBjbGFzc05hbWU9XCJtYi0zIHRleHQteGwgdGV4dC1ibHVlLTMwMFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItMyB0ZXh0LXhsIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmZWF0dXJlLnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC16aW5jLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2ZlYXR1cmUuZGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2FydGljbGU+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgKTtcclxufSJdfQ==