import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import BackToTopButton from "/src/components/common/BackToTopButton.jsx";
import SiteFooter from "/src/components/layout/SiteFooter.jsx";
import SiteHeader from "/src/components/layout/SiteHeader.jsx";
import LandingSections from "/src/components/sections/LandingSections.jsx";
import { useRevealOnScroll } from "/src/hooks/useRevealOnScroll.js";
import { useScrollState } from "/src/hooks/useScrollState.js";
var _jsxFileName = "C:/Users/uelin/Desktop/AI Company Landing/src/App.jsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12888fd9";
var _s = $RefreshSig$();
function App() {
	_s();
	useRevealOnScroll();
	const { isScrolled, showTopButton } = useScrollState();
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "relative min-h-screen overflow-hidden bg-black text-zinc-100",
		children: [
			/* @__PURE__ */ _jsxDEV("div", { className: "glow glow-cyan" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 16,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { className: "glow glow-violet" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 17,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { className: "pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top, rgba(255,255,255,0.08), transparent_45%)]" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mx-auto max-w-6xl px-6 py-24 lg:px-8",
				children: [
					/* @__PURE__ */ _jsxDEV(SiteHeader, { isScrolled }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 21,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(LandingSections, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 24,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(SiteFooter, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 26,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(BackToTopButton, { show: showTopButton }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 5
	}, this);
}
_s(App, "Mq9+zPxG7jtLBZQmFTgpc+FPd34=", false, function() {
	return [useRevealOnScroll, useScrollState];
});
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/uelin/Desktop/AI Company Landing/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/uelin/Desktop/AI Company Landing/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/uelin/Desktop/AI Company Landing/src/App.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxxQkFBcUI7QUFDNUIsT0FBTyxnQkFBZ0I7QUFDdkIsT0FBTyxnQkFBZ0I7QUFDdkIsT0FBTyxxQkFBcUI7QUFFNUIsU0FBUyx5QkFBeUI7QUFDbEMsU0FBUyxzQkFBc0I7Ozs7QUFFL0IsU0FBUyxNQUFNOztDQUNiLGtCQUFrQjtDQUVsQixNQUFNLEVBQUUsWUFBWSxrQkFBa0IsZUFBZTtDQUVyRCxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxPQUFELEVBQUssV0FBVSxpQkFBa0I7Ozs7O0dBQ2pDLHdCQUFDLE9BQUQsRUFBSyxXQUFVLG1CQUFvQjs7Ozs7R0FDbkMsd0JBQUMsT0FBRCxFQUFLLFdBQVUsb0hBQXFIOzs7OztHQUVwSSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsWUFBRCxFQUNjLFdBQWE7Ozs7O0tBRTNCLHdCQUFDLGlCQUFELENBQWtCOzs7OztLQUVsQix3QkFBQyxZQUFELENBQWE7Ozs7O0lBQ1Y7Ozs7OztHQUVMLHdCQUFDLGlCQUFELEVBQWlCLE1BQU0sY0FBZ0I7Ozs7O0VBQ3BDOzs7Ozs7QUFFVDs7Ozs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEJhY2tUb1RvcEJ1dHRvbiBmcm9tIFwiLi9jb21wb25lbnRzL2NvbW1vbi9CYWNrVG9Ub3BCdXR0b25cIjtcclxuaW1wb3J0IFNpdGVGb290ZXIgZnJvbSBcIi4vY29tcG9uZW50cy9sYXlvdXQvU2l0ZUZvb3RlclwiO1xyXG5pbXBvcnQgU2l0ZUhlYWRlciBmcm9tIFwiLi9jb21wb25lbnRzL2xheW91dC9TaXRlSGVhZGVyXCI7XHJcbmltcG9ydCBMYW5kaW5nU2VjdGlvbnMgZnJvbSBcIi4vY29tcG9uZW50cy9zZWN0aW9ucy9MYW5kaW5nU2VjdGlvbnNcIjtcclxuXHJcbmltcG9ydCB7IHVzZVJldmVhbE9uU2Nyb2xsIH0gZnJvbSBcIi4vaG9va3MvdXNlUmV2ZWFsT25TY3JvbGxcIjtcclxuaW1wb3J0IHsgdXNlU2Nyb2xsU3RhdGUgfSBmcm9tIFwiLi9ob29rcy91c2VTY3JvbGxTdGF0ZVwiO1xyXG5cclxuZnVuY3Rpb24gQXBwKCkge1xyXG4gIHVzZVJldmVhbE9uU2Nyb2xsKClcclxuXHJcbiAgY29uc3QgeyBpc1Njcm9sbGVkLCBzaG93VG9wQnV0dG9uIH0gPSB1c2VTY3JvbGxTdGF0ZSgpO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBtaW4taC1zY3JlZW4gb3ZlcmZsb3ctaGlkZGVuIGJnLWJsYWNrIHRleHQtemluYy0xMDBcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJnbG93IGdsb3ctY3lhblwiIC8+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2xvdyBnbG93LXZpb2xldFwiIC8+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtbm9uZSBhYnNvbHV0ZSBpbnNldC0wIGJnLVtyYWRpYWwtZ3JhZGllbnQoY2lyY2xlX2F0X3RvcCwgcmdiYSgyNTUsMjU1LDI1NSwwLjA4KSwgdHJhbnNwYXJlbnRfNDUlKV1cIiAvPlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC1hdXRvIG1heC13LTZ4bCBweC02IHB5LTI0IGxnOnB4LThcIj5cclxuICAgICAgICA8U2l0ZUhlYWRlciBcclxuICAgICAgICAgIGlzU2Nyb2xsZWQ9e2lzU2Nyb2xsZWR9IC8+XHJcblxyXG4gICAgICAgIDxMYW5kaW5nU2VjdGlvbnMgLz5cclxuXHJcbiAgICAgICAgPFNpdGVGb290ZXIgLz5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8QmFja1RvVG9wQnV0dG9uIHNob3c9e3Nob3dUb3BCdXR0b259IC8+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBcHA7Il19