import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sections/WorkflowSection.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { workflowSteps } from "/src/data/landingData.js";
var _jsxFileName = "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/WorkflowSection.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12888fd9";
export default function WorkflowSection() {
	return /* @__PURE__ */ _jsxDEV("section", {
		"data-reveal": true,
		className: "reveal-up rounded-2xl border border-zinc-800 bg-zinc-900/35 p-8",
		children: [/* @__PURE__ */ _jsxDEV("h2", {
			className: "mb-8 text-2xl font-semibold md:text-3xl",
			children: "Como Desenvolvemos uma IA que Faz Você Crescer"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 9,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "grid gap-6 md:grid-cols-3",
			children: workflowSteps.map((item) => /* @__PURE__ */ _jsxDEV("article", {
				className: "rounded-xl border border-zinc-800 bg-zinc-900 p-6 transition-all duration-300 hover:-translate-y-1 hover:border-blue-400/40",
				children: [
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mb-3 text-sm font-semibold tracking-widest text-blue-300",
						children: item.step
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 19,
						columnNumber: 25
					}, this),
					/* @__PURE__ */ _jsxDEV("h3", {
						className: "mb-3 text-xl font-semibold",
						children: item.title
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 23,
						columnNumber: 25
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-zinc-300",
						children: item.detail
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 25
					}, this)
				]
			}, item.step, true, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 21
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 13,
			columnNumber: 13
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 5,
		columnNumber: 9
	}, this);
}
_c = WorkflowSection;
var _c;
$RefreshReg$(_c, "WorkflowSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/sections/WorkflowSection.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/WorkflowSection.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/WorkflowSection.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/uelin/Desktop/AI Company Landing/src/components/sections/WorkflowSection.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxxQkFBcUI7OztBQUU5QixlQUFlLFNBQVMsa0JBQWtCO0NBQ3RDLE9BQ0ksd0JBQUMsV0FBRDtFQUNJO0VBQ0EsV0FBVTtZQUZkLENBSUksd0JBQUMsTUFBRDtHQUFJLFdBQVU7YUFBMEM7RUFFcEQ7Ozs7WUFFSix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNWLGNBQWMsS0FBSyxTQUNoQix3QkFBQyxXQUFEO0lBRUksV0FBVTtjQUZkO0tBSUksd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQ1IsS0FBSztLQUNQOzs7OztLQUVILHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUNULEtBQUs7S0FDTjs7Ozs7S0FFSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFDUixLQUFLO0tBQ1A7Ozs7O0lBQ0U7TUFkQSxLQUFLOzs7O1VBY0wsQ0FDWjtFQUNBOzs7O1VBQ0E7Ozs7OztBQUVqQiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJXb3JrZmxvd1NlY3Rpb24uanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHdvcmtmbG93U3RlcHMgfSBmcm9tIFwiLi4vLi4vZGF0YS9sYW5kaW5nRGF0YVwiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gV29ya2Zsb3dTZWN0aW9uKCkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8c2VjdGlvblxyXG4gICAgICAgICAgICBkYXRhLXJldmVhbFxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJyZXZlYWwtdXAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci16aW5jLTgwMCBiZy16aW5jLTkwMC8zNSBwLThcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cIm1iLTggdGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtZDp0ZXh0LTN4bFwiPlxyXG4gICAgICAgICAgICAgICAgQ29tbyBEZXNlbnZvbHZlbW9zIHVtYSBJQSBxdWUgRmF6IFZvY8OqIENyZXNjZXJcclxuICAgICAgICAgICAgPC9oMj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtNiBtZDpncmlkLWNvbHMtM1wiPlxyXG4gICAgICAgICAgICAgICAge3dvcmtmbG93U3RlcHMubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGFydGljbGVcclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpdGVtLnN0ZXB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci16aW5jLTgwMCBiZy16aW5jLTkwMCBwLTYgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGhvdmVyOi10cmFuc2xhdGUteS0xIGhvdmVyOmJvcmRlci1ibHVlLTQwMC80MFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtYi0zIHRleHQtc20gZm9udC1zZW1pYm9sZCB0cmFja2luZy13aWRlc3QgdGV4dC1ibHVlLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uc3RlcH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTMgdGV4dC14bCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtemluYy0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmRldGFpbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvYXJ0aWNsZT5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICApO1xyXG59Il19